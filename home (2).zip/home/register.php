<?php
if(!empty($_POST['mail']) && !empty($_POST['name']) && !empty($_POST['surname']) && !empty($_POST['pass']) && !empty($_POST['urlAva']) && !empty($_POST['birthday'])){
    $mail = $_POST['mail'];
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $password = $_POST['pass'];
    $url = $_POST['urlAva'];
    $bdate = $_POST['birthday'];

    require "link.php";

    $stmt = $link->prepare("INSERT INTO asf (email, name, surname, password, img, birthday) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $mail, $name, $surname, $password, $url, $bdate);
    $result = $stmt->execute();
    if($result === true){
        echo "success";
    }
    else{
        echo "failed reg";
    }
}
else{
    echo "failed";
}