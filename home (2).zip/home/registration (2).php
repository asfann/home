<?php

session_start();
header('location:login.html')

$con = mysqli_connect('localhost','asfa','uXLB5ClvBvnaFdig');

mysqli_select_db($con, 'endterm');

$name=$_POST['user'];
$pass=$_POST['Password'];

$s = "SELECT * FROM usertable WHERE name = '$name'";

$res=mysqli_query($con,$s);

$num=mysqli_num_rows($res);

if ($num==1) {
	echo"Username is alreaty taken";
}else{
	$reg="INSERT INTO usertable(name,password) values('$name','$pass')";
	mysqli_query($con,$reg);
	echo"Registration success";
}
?>