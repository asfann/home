<?php
$db_name = 'blog';
$db_host = 'localhost';
$db_user = 'beknazar';
$db_pass = 'AQ0iTPAy5W4MJ9Te';  

$conn = mysqli_connect($db_host,$db_user,$db_pass,$db_name);

if(mysqli_connect_error()){
    echo mysqli_connect_erro();
}

?>