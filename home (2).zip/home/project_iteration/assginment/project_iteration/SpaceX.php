<?php
require 'database.php';
?>
<!DOCTYPE html> 
<html>
    <head>
        <link rel="stylesheet" href="styleX.css" >
        <script src="JavaS.js"></script>
        <meta charset="UTF-8">
        <title>SpaceX</title>
    </head>
    <body>
       
            <header>
            <div id="logo" onclick="slowScroll('top')">
                <span>Space X</span>
            </div>
            <div id="about">
                <a href= ""  id="about_first">HOME</a>
                <a href="About.html" >ABOUT</a>
                <a href="SpaceX_shop.html" target="_blank" >SHOP</a>
                
            </div>
        </header>

                    <div id="top"> 
                        <h1>Into the future </h1>
                        <h3>Through innovation</h3>
                    </div>

                            <div id="main">
                                <div class="intro">
                                    <h2>About SpaceX</h2>
                                    <span>
                                        Quality Innovation Future </span>
                                </div>
                                <div class="text">
                                    <span>SpaceX designs, manufactures and launches advanced rockets and spacecraft. The company was founded in 2002 to revolutionize space technology, with the ultimate goal of enabling people to live on other planets.</span>
                                </div>
                            </div>

    <div id="overview">

    </div>

    <div id="fl">
        <div id="first" onclick="change(1)">Crew Dragon</div>
        <div id="second" onclick="change(2)">Starlink</div>
        <div id="third" onclick="change(3)">Falcon Heavy</div>
    </div>

    <div id="contacts">
        <center><h5>Feedback</h5></center>
        <center><p style="font-family:'Quicksand', sans-serif  ;">
        <?php
        require 'database.php';
            if($_SERVER["REQUEST_METHOD"]=="POST"){
                $sql = "INSERT INTO review(Name, Email , Message )
                VALUES('".$_POST['name']."','".$_POST['email']."','".$_POST['message']."')";
                    $res=mysqli_query($conn,$sql); 
                    if($res===false){
                        echo mysqli_error($conn);
                    }
                    else{
                        $id=mysqli_insert_id($conn);
                        echo '<br>'."Message was send by id :$id";
                }
        }
?>
</p></center>
        <form id="form_input" method="POST" >
            <label for="name">Name <span>*</span></label><br>
            <input type="text" placenholder="input the name" name="name" id="name"><br>
            <label for="email">Your eMail<span>*</span></label><br>
            <input type="email" placeholder="Input the eMail" name="email" id="email"><br>
            <label for="message">Message <span>*</span></label><br>
            <textarea placeholder="Enter the your message" name="message" id="message"></textarea><br>
          <input type="submit" id="mess_send" class="btn" value="Send">
        </form>
    </div>

   
    <h1 style="font-size: 3.5em; margin-top: 30px; margin-left: 100px; float: left; color: white;">RATE OUR WEBSITE : </h1>
    
    <div class="rating-area">
        
        <input type="radio" id="star-5" name="rating" value="5">
        <label for="star-5" title="Оценка «5»"></label>	
        <input type="radio" id="star-4" name="rating" value="4">
        <label for="star-4" title="Оценка «4»"></label>    
        <input type="radio" id="star-3" name="rating" value="3">
        <label for="star-3" title="Оценка «3»"></label>  
        <input type="radio" id="star-2" name="rating" value="2">
        <label for="star-2" title="Оценка «2»"></label>    
        <input type="radio" id="star-1" name="rating" value="1">
        <label for="star-1" title="Оценка «1»"></label>
    </div>

    <div id="f">
             
        <div> <a href="https://shop.spacex.com/pages/faqs">FAQs</a></div>
        
        <div> <a href="https://shop.spacex.com/policies/privacy-policy">Privacy Policy</a></div>
        <div> <a href="https://shop.spacex.com/policies/terms-of-service"> Terms & Conditions</a></div>
     </div>
            <div id="f_down">
                <a>@ SPACEX STORE</a>
            </div>


           

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        function slowScroll(id){
            $('html,body').animate({
                scrollTop:$(id).offset().top
            },500);
        }

        $(document).on("scroll",function(){
            if($(window).scrollTop() === 0) 
            $("header").removeClass("fixed");
            else
            $("header").attr("class","fixed");
             });


           
    </script>
    </body>
</html>