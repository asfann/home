function change(arg){
    document.getElementById('overview').style.backgroundSize = '130%';
    // document.getElementById('overview').style.padding = '10%';
if(arg==2){
    document.getElementById('overview').style.backgroundImage = 'url(https://www.teslarati.com/wp-content/uploads/2019/06/Starlink-coverage-Earth-SpaceX-3.gif)';
}else if(arg == 1){
    document.getElementById('overview').style.backgroundImage = 'url(https://thumbs.gfycat.com/DisloyalFaintAmericanmarten-size_restricted.gif)';
}else if(arg==3){
    document.getElementById('overview').style.backgroundImage = 'url(https://techcrunch.com/wp-content/uploads/2019/08/spacex-rideshare.gif?w=730&crop=1)';
}

}

function rocket(arg){
    window.open('rockets.html');
}