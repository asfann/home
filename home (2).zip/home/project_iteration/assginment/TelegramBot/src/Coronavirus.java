import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.IOException;

public class Coronavirus {
    private Document document;

    public String getProp(){
        try{
document = Jsoup.connect("https://www.google.com/search?q=%D0%BF%D1%80%D0%BE%D1%84%D0%B8%D0%BB%D0%B0%D0%BA%D1%82%D0%B8%D0%BA%D0%B0+%D0%BA%D0%BE%D1%80%D0%BE%D0%BD%D0%B0%D0%B2%D0%B8%D1%80%D1%83%D1%81%D0%B0&rlz=1C1CHBD_enKZ874KZ874&oq=coronavirus+s&aqs=chrome.1.69i57j0l4j69i60l3.8003j0j7&sourceid=chrome&ie=UTF-8&stick=H4sIAAAAAAAAAONgVuLVT9c3NMwySk6OL8zJecTozS3w8sc9YSmnSWtOXmO04eIKzsgvd80rySypFNLjYoOyVLgEpVB1ajBI8XOhCvHsYhLwSE3MKckIKEotSwXqzM9bxGp4Yf_Fhgv7LrZc2HFh94UNF3ZdbAKydl3YoAAk9oGkLuwFCm-6sONiw8Xmi40XNgAAP76W8KYAAAA&ictx=1&ved=2ahUKEwjh2Irf-u3pAhUIEJoKHWarB6AQyNoBKAR6BAgSEA0").get();
        }catch (IOException e){
            e.printStackTrace();
        }
        Elements elements = document.getElementsByClass("PZPZlf");
        String info = elements.text();
        int ind = 0;
        String rr = "";
        for (int i = 0; i < info.length(); i++) {
            if (info.charAt(i) == ':') {
                rr += info.substring(ind, i - 2) + "\n";
                ind = i - 2;
            }
            if (i + 11 > info.length()) {
                break;
            } else {
                if (info.charAt(i + 8) == '2' && info.charAt(i + 9) == '0' && info.charAt(i + 10) == '2' && info.charAt(i + 11) == '0') {
                    rr += "\n";
                }
            }
        }
        return rr;
    }

public String getSymp(){
    try{
        document = Jsoup.connect("https://www.google.com/search?q=%D1%81%D0%B8%D0%BC%D0%BF%D1%82%D0%BE%D0%BC%D1%8B+%D0%BA%D0%BE%D1%80%D0%BE%D0%BD%D0%B0%D0%B2%D0%B8%D1%80%D1%83%D1%81%D0%B0&rlz=1C1CHBD_enKZ874KZ874&oq=coronavirus+s&aqs=chrome.1.69i57j0l4j69i60l3.8003j0j7&sourceid=chrome&ie=UTF-8&stick=H4sIAAAAAAAAAONgVuLVT9c3NMwySk6OL8zJecTozS3w8sc9YSmnSWtOXmO04eIKzsgvd80rySypFNLjYoOyVLgEpVB1ajBI8XOhCvHsYuLzSE3MKckIrswtKMnPLV7Eqnmx8cKOC3su7L_YdGHfhT0XuxUu7Lqw72IDkLP3woYLmy7suNhwsRmoaAMANXifGJwAAAA&ictx=1&ved=2ahUKEwiq2ZrIhu7pAhWwtIsKHUuUCTUQyNoBKAF6BAgSEAo").get();
    }catch (IOException e){
        e.printStackTrace();
    }
    Elements elements = document.getElementsByClass("PZPZlf");
            String info = elements.text();
    int ind = 0;
    String ll = "";
    for (int i = 0; i < info.length(); i++) {
        if (info.charAt(i) == ':') {
            ll += info.substring(ind, i - 2) + "\n";
            ind = i - 2;
        }
        if (i + 11 > info.length()) {
            break;
        } else {
            if (info.charAt(i + 8) == '2' && info.charAt(i + 9) == '0' && info.charAt(i + 10) == '2' && info.charAt(i + 11) == '0') {
                ll += "\n";
            }
        }
    }
    return ll;

}
public String getHelp(){
    try{
        document = Jsoup.connect("https://www.google.com/search?rlz=1C1CHBD_enKZ874KZ874&sxsrf=ALeKk02ghnN3FnxWuWzVBHQe7VGtIGrYcQ%3A1591479021136&ei=7QrcXr33B6-GwPAPko2tmAg&q=%D0%BB%D0%B5%D1%87%D0%B5%D0%BD%D0%B8%D0%B5+%D0%BA%D0%BE%D1%80%D0%BE%D0%BD%D0%B0%D0%B2%D0%B8%D1%80%D1%83%D1%81%D0%B0&oq=%D0%BB%D0%B5&gs_lcp=CgZwc3ktYWIQAxgAMgQIIxAnMgQIABBDMgQIABBDMgQIABBDMgQIABBDMgcIABCDARBDMgcIABCDARBDMgQIABBDMgcIABCxAxBDMgUIABCxAzoHCCMQ6gIQJzoCCAA6BQgAEIMBUOCQEVjXmxFgpqURaAJwAHgAgAFriAG1ApIBAzEuMpgBAKABAaoBB2d3cy13aXqwAQo&sclient=psy-ab").get();
    }catch (IOException e){
        e.printStackTrace();
    }
    Elements elements = document.getElementsByClass("PZPZlf");
    String info = elements.text();
    int ind = 0;
    String qq = "";
    for (int i = 0; i < info.length(); i++) {
        if (info.charAt(i) == ':') {
            qq += info.substring(ind, i - 2) + "\n";
            ind = i - 2;
        }
        if (i + 11 > info.length()) {
            break;
        } else {
            if (info.charAt(i + 8) == '2' && info.charAt(i + 9) == '0' && info.charAt(i + 10) == '2' && info.charAt(i + 11) == '0') {
                qq += "\n";
            }
        }
    }
    return qq;

}

    public String getTotalCases() {

        Elements elements = document.getElementsByClass("maincounter-number");
        return elements.text();

    }

}



