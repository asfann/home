import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class Covid {
    private Document document;

    public Covid(){
        connect();
    }

    private void connect(){
        try {
            document = Jsoup.connect("https://www.worldometers.info/coronavirus/country/uk/").get();
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public String getCountry(String country){
        try {
            document = Jsoup.connect("https://www.worldometers.info/coronavirus/country/" + country + "/").get();
        }catch(IOException e){
            e.printStackTrace();
        }
        return document.title();
    }


    public String getTotalCases(){
        Elements elements = document.getElementsByClass("maincounter-number");
        return elements.text();
    }


}
