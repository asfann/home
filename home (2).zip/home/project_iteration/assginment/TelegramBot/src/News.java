import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class News {
    private Document document;


    public String getNewsKZ() {
        try {
            document = Jsoup.connect("https://www.zakon.kz/s/koronavirus-v-kazahstane/").get();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Elements elements = document.getElementsByClass("cat_news_item");
        String info = elements.text();
        int ind = 0;
        String ll = "";
        for (int i = 0; i < info.length(); i++) {
            if (info.charAt(i) == ':') {
                ll += info.substring(ind, i - 2) + "\n";
                ind = i - 2;
            }
            if (i + 11 > info.length()) {
                break;
            } else {
                if (info.charAt(i + 8) == '2' && info.charAt(i + 9) == '0' && info.charAt(i + 10) == '2' && info.charAt(i + 11) == '0') {
                    ll += "\n";
                }
            }
        }
        return ll;
    }

    public String getNews() {
        try {
            document = Jsoup.connect("https://www.worldometers.info/coronavirus/").get();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Elements elements = document.getElementsByClass("news_post");
        String info = elements.text();
        int ind = 0;
        String rr = "";
        for (int i = 0; i < info.length(); i++) {
            if (info.charAt(i) == ':') {
                rr += info.substring(ind, i - 2) + "/n";
                ind = i - 2;
            }
            if (i + 11 > info.length()) {
                break;
            } else {
                if (info.charAt(i + 8) == '2' && info.charAt(i + 9) == '0' && info.charAt(i + 10) == '2' && info.charAt(i + 11) == '0') {
                    rr += "/n";
                }
            }
        }
        return rr;
    }


    public String getTotalCases() {

        Elements elements = document.getElementsByClass("maincounter-number");
        return elements.text();

    }
}