import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.util.ArrayList;

public class Bot extends TelegramLongPollingBot {
    Covid covid = new Covid();
    News news = new News();
    Top top = new Top();
    Coronavirus corona = new Coronavirus();
    private long chat_id;
    String lastMessage = "";
    ReplyKeyboardMarkup replyKeyboardMarkup = new ReplyKeyboardMarkup();

    @Override
    public void onUpdateReceived(Update update) {
        update.getUpdateId();
        SendMessage sendMessage = new SendMessage().setChatId(update.getMessage().getChatId());
        chat_id = update.getMessage().getChatId();
        sendMessage.setText(getMessage(update.getMessage().getText()));
        sendMessage.setReplyMarkup(replyKeyboardMarkup);

            try{
                execute(sendMessage);
            } catch(TelegramApiException e){
                e.printStackTrace();
            }
        }


        public String getTopr(){
        String info = top.getTopRecov();
        return info;
        }

        public String getProp(){
        String info = corona.getProp();
        return info;
        }

        public String getSymp(){
        String info = corona.getSymp();
        return info;
        }

        public String getHelp(){
        String info = corona.getHelp();
        return info;
        }

        public String getTops(){
        String info = top.getTopSick();
        return info;
        }

        public String getN(){
        String info = news.getNews();
        return info;
        }

    public String getNews(){
        String info = news.getNewsKZ();
        return info;
    }


    public String getCovidInfo(String country){
        String info = covid.getCountry(country);
        return info;
    }

    public String getMessage(String msg){
        ArrayList<KeyboardRow> keyboard = new ArrayList<>();
        KeyboardRow keyboardFirstRow = new KeyboardRow();
        KeyboardRow keyboardSecondRow = new KeyboardRow();
        KeyboardRow keyboardThirdRow = new KeyboardRow();
        KeyboardRow keyboardFourthRow = new KeyboardRow();
        KeyboardRow keyboardFifthRow = new KeyboardRow();

        replyKeyboardMarkup.setSelective(true);
        replyKeyboardMarkup.setResizeKeyboard(true);
        replyKeyboardMarkup.setOneTimeKeyboard(false);

        if(msg.equals("Меню") || msg.equals("/start")){
            keyboard.clear();
            keyboardFirstRow.clear();
            keyboardFirstRow.add("Статистика");
            keyboardFirstRow.add("Новости Казахстана");
            keyboardSecondRow.add("Новости Мира");
            keyboardThirdRow.add("Симптомы");
            keyboardThirdRow.add("Профилактика");
            keyboardThirdRow.add("Самостоятельное лечение");
            keyboard.add(keyboardFirstRow);
            keyboard.add(keyboardSecondRow);
            keyboard.add(keyboardThirdRow);
            replyKeyboardMarkup.setKeyboard(keyboard);
            return "Выбрать...";
        }

        if(msg.equals("Статистика")){
            keyboard.clear();
            keyboardFirstRow.clear();
            keyboardFirstRow.add("Выбор стран");
            keyboardFirstRow.add("Топ стран по заболеванию");
            keyboardSecondRow.add("Топ стран по выздоровлению");
            keyboardSecondRow.add("Меню");
            keyboard.add(keyboardFirstRow);
            keyboard.add(keyboardSecondRow);
            replyKeyboardMarkup.setKeyboard(keyboard);
            return "Выбрать...";
        }

        if(msg.equals("Симптомы")){
            return getSymp();
        }

        if(msg.equals("Профилактика")){
            return getProp();
        }

        if(msg.equals("Самостоятельное лечение")){
            return getHelp();
        }

        if(msg.equals("Новости Казахстана")){
            return getNews();
        }
        
        if(msg.equals("Новости Мира")){
            return getN();
        }
        
        if(msg.equals("Топ стран по заболеванию")){
            return getTops();
        }
        
        if(msg.equals("Топ стран по выздоровлению")){
           return  getTopr();
        }

        if(msg.equals("Выбор стран")){
            lastMessage = msg;
            keyboard.clear();
            keyboardFirstRow.add("UK");
            keyboardFirstRow.add("Kazakhstan");
            keyboardFirstRow.add("Russia");
            keyboardSecondRow.add("Brazil");
            keyboardSecondRow.add("China");
            keyboardSecondRow.add("Japan");
            keyboardThirdRow.add("Canada");
            keyboardThirdRow.add("France");
            keyboardThirdRow.add("India");
            keyboardFourthRow.add("Italy");
            keyboardFourthRow.add("Turkey");
            keyboardFourthRow.add("Germany");
            keyboardFifthRow.add("Mexico");
            keyboardFifthRow.add("Chile");
            keyboardFifthRow.add("Iran");
            keyboard.add(keyboardFirstRow);
            keyboard.add(keyboardSecondRow);
            keyboard.add(keyboardThirdRow);
            keyboard.add(keyboardFourthRow);
            keyboard.add(keyboardFifthRow);
            replyKeyboardMarkup.setKeyboard(keyboard);
            return "Выберите пункт меню";
        }

        if(lastMessage.equals("Выбор стран")){
           return getCovidInfo(msg.toLowerCase());
        }
        return "Напишите /start";
    }

    @Override
    public String getBotUsername() {
        return "@SneakerShop";
    }

    @Override
    public String getBotToken() {
        return "1059541355:AAE2-XVzmo03hrcP7WSQuNOzGzJWna2VtVI";
    }
}
