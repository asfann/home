import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.IOException;

public class Top {
private Document document;

    public String getTopSick(){
            try{
                document = Jsoup.connect("https://www.worldometers.info/coronavirus/#countries").get();
            }catch(IOException e){
                e.printStackTrace();
            }
        Elements elements = document.getElementsByClass("css-kfswhc svelte-nim44h");
        String info = elements.text();
        int inf = 0;
        String kk = "";
        for(int i = 0 ; i < info.length(); i++){
            if(info.charAt(i) == ':'){
                kk += info.substring(inf, i - 2) + "\n";
                inf = i - 2;
            }
            if(i + 11 > info.length()){
                break;
            }
            else {
                if (info.charAt(i + 8) == '2' && info.charAt(i + 9) == '0' && info.charAt(i + 10) == '2' && info.charAt(i + 11) == '0') {
                    kk += "\n";
                }
            }
        }
        return kk;
    }




    public String getTopRecov() {
            try{
                document = Jsoup.connect("https://tradingeconomics.com/country-list/coronavirus-recovered").get();
            }catch(IOException e){
                e.printStackTrace();
            }
        Elements elements = document.getElementsByClass("table-responsive");
        String info = elements.text();
        int inf = 0;
        String kk = "";
        for(int i = 0 ; i < info.length(); i++){
            if(info.charAt(i) == ':'){
                kk += info.substring(inf, i - 2) + "\n";
                inf = i - 2;
            }
            if(i + 11 > info.length()){
                break;
            }
            else {
                if (info.charAt(i + 8) == '2' && info.charAt(i + 9) == '0' && info.charAt(i + 10) == '2' && info.charAt(i + 11) == '0') {
                    kk += "\n";
                }
            }
        }
        return kk;
    }

    public String getTotalCases(){
        Elements elements = document.getElementsByClass("maincounter-number");
        return elements.text();
    }

}
