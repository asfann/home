<?php
session_start();
if (!isset($_SESSION['username'])) {
  header('location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css/star.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/parallax.min.js"></script>
    <title>Films</title>
  </head>
  <body>
   <header class="head">
   	<a href="mmain.php"><img src="img/star wars.png" class="logo" alt="logo" style="width: 60px;
  height: 45px;"></a>
  <nav>
    <ul class="nav_links">
      <li><a href="star.php" class="ad">Games</a></li>
      <li><a href="serials.php" class="ad">Series</a></li>
    <li><a href="characters.php" class="ad">Characters</a></li>
      <li><a href="#p1" class="add">The Original Trilogy</a></li>
      <li><a href="#p2" class="add">The Prequel Trilogy</a></li>
      <li><a href="#p3" class="add">The Sequel Trilogy</a></li>
      <li><a href="#p4" class="add">A Star Wars Story</a></li>
    </ul>
  </nav>
  <div class="popup" id="popup-1" >
  <div class="overlay"></div>
  <div class="content">
    <div class="close-btn" onclick="togglePopup()">&times;</div>
    <h1 style="color:  #edf0f1;">About Us</h1>
    <p style="color:  #edf0f1;">Welcome to website about Star Wars, your number one source for all information about Star Wars Saga.
Founded in 2020 by Asfandiyar Marat, Star Wars has come a long way from its beginnings in ASTANA IT UNIVERSITY. When Asfandiyar first started out, his passion for mat force be with you drove him to do tons of research so that Star Wars can offer you clear information about Skywalker Saga.</p>
  </div>
</div>
  <button onclick="togglePopup()">About us</button>
</header>
    <div class="parallax-window" data-parallax="scroll" data-z-index="1" data-image-src="img/firstt.webp">
    	<div class="container">
    <p class="info" id="p1"><b>THE ORIGINAL TRILOGY</b><br><br>
    	<b>Star Wars: Episode IV A New Hope</b><br><br>
    Star Wars: Episode IV A New Hope, originally released as Star Wars, and currently marketed as simply Star Wars: A New Hope is a 1977 film written and directed by George Lucas. It is the first film in the Star Wars original trilogy.<br>

The film is set about nineteen years after the formation of the Galactic Empire; construction has finished on the Death Star, a weapon capable of destroying a planet. After Princess Leia Organa, a leader of the Rebel Alliance, receives the weapon's plans in the hope of finding a weakness, she is captured and taken to the Death Star. Meanwhile, a young farmer named Luke Skywalker meets Obi-Wan Kenobi, who has lived in seclusion for years on the desert planet of Tatooine. When Luke's home is burned and his aunt and uncle killed, Obi-Wan begins Luke's Jedi training as they—along with Han Solo, Chewbacca, C-3PO and R2-D2—attempt to rescue the princess from the Empire.<br>
<iframe width="950" height="700" src="https://www.youtube.com/embed/vZ734NWnAHA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br><br>

<b>Star Wars: Episode V The Empire Strikes Back</b><br><br>
Star Wars: Episode V The Empire Strikes Back, marketed as simply The Empire Strikes Back, is a 1980 film directed by Irvin Kershner and written by Leigh Brackett and Lawrence Kasdan from a story by George Lucas. It is the fifth episode in the Star Wars trilogy.<br>

The film concerns the continuing struggles of the Rebel Alliance against the Galactic Empire. During the film, Han Solo, Chewbacca, and Princess Leia Organa are being pursued across space by Darth Vader and his elite forces. Meanwhile, Luke Skywalker begins his major Jedi training with Yoda, after an instruction from Obi-Wan Kenobi's spirit. In an emotional and near-fatal confrontation with Vader, Luke is presented with a horrific revelation and must face his destiny.<br>
<iframe width="950" height="700" src="https://www.youtube.com/embed/JNwNXF9Y6kY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
Though controversial upon release, the film has proved to be the most popular film in the series among fans and critics and is now widely regarded as one of the best sequel films of all time, as well as one of the greatest films of all time. It was re-released with changes in 1997 and on DVD in 2004. The film was re-released on Blu-ray format in September of 2011. A radio adaptation was broadcast on National Public Radio in the U.S.A. in 1983. The film was selected in 2010 to be preserved by the Library of Congress as part of its National Film Registry.<br><br>

<b>Star Wars: Episode VI Return of the Jedi</b><br><br>
Star Wars: Episode VI Return of the Jedi, marketed as simply Return of the Jedi, is a 1983 film directed by Richard Marquand and written by Lawrence Kasdan and George Lucas from a story by Lucas. It is the sixth episode in the Star Wars saga.<br>

Luke Skywalker and friends travel to Tatooine to rescue their friend Han Solo from the vile Jabba the Hutt. The Empire prepares to crush the Rebellion with a more powerful Death Star, while the Rebel fleet mounts a massive attack on the space station. Luke Skywalker confronts his father, Darth Vader, in a final climactic duel before the evil Emperor.<br>
<iframe width="950" height="700" src="https://www.youtube.com/embed/7L8p7_SLzvU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
The film debuted on May 25, 1983, and was released on VHS and LaserDisc in this form multiple times during the 1980s and '90s. The film was re-released with changes in 1997, and this version was later released on VHS and LaserDisc as well. The special edition arrived on DVD in 2004, but with further updates and changes to the 1997 versions. The original, unaltered version of the film was released as part of a DVD set in September 2006. The film was re-released in the Blu-ray format in September of 2011.<br>
</p>		
    	</div>
    </div>
    <div class="parallax-window" data-parallax="scroll" data-z-index="1" data-image-src="img/second.jpg">
    	<div class="container">
    		<p class="info" id="p2"><b>THE PREQUEL TRILOGY</b><br><br>
    			<b>Star Wars: Episode I The Phantom Menace</b><br><br>
    			Star Wars: Episode I The Phantom Menace is a 1999 film written and directed by George Lucas, produced by Rick McCallum and starring Liam Neeson, Ewan McGregor, Natalie Portman, Jake Lloyd, and Ian McDiarmid. It is the first film in the Star Wars prequel trilogy.<br>

The Phantom Menace was released in theaters on May 19, 1999, becoming the first Star Wars film since Star Wars: Episode VI Return of the Jedi, which was released sixteen years earlier. The release was accompanied by extensive media coverage and great fan anticipation. Despite mixed reviews from critics and fans, the film grossed $924.3 million worldwide, making it the second highest-grossing Star Wars film when unadjusted for inflation. It was re-released on Blu-ray in September 2011, and was re-released in theaters in 3D on February 10, 2012.<br>
<iframe width="950" height="700" src="https://www.youtube.com/embed/bD7bpG-zDJQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
The film was the catalyst for fifteen years of Star Wars storytelling that would primarily take place around the time of the prequel storyline. The success of the film allowed for the next two chapters of the prequel trilogy, as well as the Star Wars: The Clone Wars film and television series.<br><br>
<b>Star Wars: Episode II Attack of the Clones</b><br><br>
Star Wars: Episode II Attack of the Clones is a 2002 film directed by George Lucas and written by Lucas and Jonathan Hales. It is the second film in the Star Wars prequel trilogy.<br>

The film is set ten years after the Battle of Naboo, when the galaxy is on the brink of civil war. Under the leadership of renegade Jedi Master Count Dooku, thousands of systems threaten to secede from the Republic. When an assassination attempt is made on Senator Padmé Amidala, the former Queen of Naboo, Jedi apprentice Anakin Skywalker is assigned to protect her, while his mentor Obi-Wan Kenobi is assigned to investigate the assassination attempt. Soon the Jedi are drawn into the heart of the separatist movement, and the beginning of a new threat to the galaxy: the Clone Wars.<br>
<iframe width="950" height="700" src="https://www.youtube.com/embed/gYbW1F_c9eM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br><br>
<b>Star Wars: Episode III Revenge of the Sith</b><br><br>
Star Wars: Episode III Revenge of the Sith is a 2005 film written and directed by George Lucas. It is the third and final film in the Star Wars prequel trilogy.<br>
<iframe width="950" height="700" src="https://www.youtube.com/embed/5UnjrG_N8hU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
Three years after the Battle of Geonosis and onset of the Clone Wars, the noble Jedi Knights have been leading a massive clone army into a galaxy-wide battle against the Confederacy of Independent Systems. The Supreme Chancellor of the Galactic Republic reveals his true nature as a Sith Lord as he unveils a plot to rule the galaxy by transforming the Republic into a Galactic Empire. Jedi hero Anakin Skywalker is seduced by the dark side of the Force to become Darth Sidious's new apprentice Darth Vader. The Jedi are all but eliminated with Obi-Wan Kenobi and Jedi Master Yoda forced into hiding. The only hope for the galaxy is Anakin's own offspring—the twin children born in secrecy who will grow up to become Luke Skywalker and Leia Organa.
</p>
    	</div>
    </div>
    <div class="parallax-window" data-parallax="scroll" data-z-index="1" data-image-src="img/third.webp">
    <div class="container">
    	<p class="info" id="p3"><b>THE SEQUEL TRILOGY</b><br><br>
    		<b>Star Wars: Episode VII The Force Awakens</b><br><br>
    		Star Wars: Episode VII The Force Awakens, marketed as Star Wars: The Force Awakens, is a 2015 film directed by J.J. Abrams; co-written by Abrams, Lawrence Kasdan, and Michael Arndt; and produced by Lucasfilm president Kathleen Kennedy and Bad Robot Productions. It is the first film in the Star Wars sequel trilogy. The film stars Harrison Ford, Mark Hamill, Carrie Fisher, Anthony Daniels, and Peter Mayhew reprising their original roles. The original actors are joined by a host of new actors including Daisy Ridley, John Boyega, Adam Driver, and Oscar Isaac.<br>
<iframe width="950" height="700" src="https://www.youtube.com/embed/sGbxmsDFVnE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
The story begins thirty years after the events of Star Wars: Episode VI Return of the Jedi. The First Order has risen from the ashes of the Galactic Empire and is opposed by General Leia Organa and the Resistance, both of which seek to find the missing Jedi Master Luke Skywalker. In the midst of this search, new heroes rise in the form of Rey, a Force-sensitive scavenger from Jakku; Finn, a stormtrooper who defected from the First Order; and Poe Dameron, the best pilot in the Resistance. They are aided by Han Solo in their search for Skywalker and their mission to destroy the First Order's new superweapon, Starkiller Base, which targets the New Republic and the Resistance for destruction. They are opposed by villains such as Kylo Ren, a dark warrior with a mysterious past; and General Armitage Hux, the commander of Starkiller Base.<br><br>
<b>Star Wars: Episode VIII The Last Jedi</b><br><br>
Star Wars: Episode VIII The Last Jedi, marketed as Star Wars: The Last Jedi, is a 2017 film written and directed by Rian Johnson and produced by Kathleen Kennedy and Ram Bergman, along with executive producer J.J. Abrams. It is the second film in the Star Wars sequel trilogy. The film sees the return of Mark Hamill, Carrie Fisher, Adam Driver, Daisy Ridley, John Boyega, Oscar Isaac, Lupita Nyong'o, Domhnall Gleeson, Anthony Daniels, Gwendoline Christie, and Andy Serkis. New cast members include Benicio Del Toro, Laura Dern, and Kelly Marie Tran.<br>
<iframe width="950" height="700" src="https://www.youtube.com/embed/Q0CbN8sfihY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
The Last Jedi begins immediately after the events of Star Wars: Episode VII The Force Awakens, set thirty years after the conclusion of the original Star Wars trilogy. It continues the story of Rey and her discovery of the exiled Jedi Master Luke Skywalker, along with the story of the war between General Leia Organa's Resistance and the First Order.<br><br>
<b>Star Wars: Episode IX The Rise of Skywalker</b><br><br>
A year after the battle of Crait, Supreme Leader Kylo Ren leads a vicious assault against Alazmec colonists on Mustafar, seeking a wayfinder owned by Ren's grandfather, Darth Vader; he requires the device as a guide in his hunt for the returned Sith Emperor Palpatine, who he perceives as a threat to his power. The Leader slaughters many colonists alongside his stormtroopers before retrieving the device and slotting it into his ship, allowing its dark power to lead him through the crimson energy storms that surround the fabled Sith vastness of Exegol.<br>
<iframe width="950" height="700" src="https://www.youtube.com/embed/8Qn_spdM5Zg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
Landing at the foot of an enormous citadel, Ren ignites his blade and enters, eventually reaching a vast chamber lined with worn statues of Sith legends. As he descends into its depths, he hears the Emperor mocking him; Ren's declaration that he had killed Snoke is dismissed: "I made Snoke."</p>
    </div>	
    </div>
    <div class="parallax-window" data-parallax="scroll" data-z-index="1" data-image-src="img/fourthh.jpg">
    	<div class="container">
    		<p class="info" id="p4">
    			<b>A STAR WARS STORY  </b><br><br>
    			<b>Rogue One: A Star Wars Story</b><br><br>
    			Approximately six years after the formation of the Galactic Empire, Imperial Director Orson Krennic and a squad of his death troopers land on the planet Lah'mu and forcibly recruit scientist Galen Erso to complete the work of the Death Star, a space station capable of destroying entire planets. Galen's wife, Lyra Erso, is killed when she shoots and injures Krennic to stop him from taking her husband. Their daughter, Jyn Erso, goes into hiding until Saw Gerrera, leader of the Partisans, rescues her and takes her in.<br><iframe width="950" height="700" src="https://www.youtube.com/embed/frdj1zb9sMY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br><br>
    			<b>Solo: A Star Wars Story</b><br><br>
    			Board the Millennium Falcon and journey to a galaxy far, far away in Solo: A Star Wars Story, an all-new adventure with the most beloved scoundrel in the galaxy. Through a series of daring escapades deep within a dark and dangerous criminal underworld, Han Solo meets his mighty future copilot Chewbacca and encounters the notorious gambler Lando Calrissian, in a journey that will set the course of one of the Star Wars saga's most unlikely heroes.<br>
    			<iframe width="950" height="700" src="https://www.youtube.com/embed/jPEYpryMp2s" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    			Six years after the formation of the Galactic Empire, on the shipbuilding world of Corellia, a human "scrumrat" and aspiring pilot named Han and his love interest Qi'ra long to escape the clutches of the Grindalid crime boss Lady Proxima's White Worms crime syndicate. Following a delivery job that went awry, Han flees some criminals on his M-68 landspeeder through the streets of Coronet City. He drives through a bridge and hangs his dice on the windscreen.<br><br>
    			<b>STAR WARS A CLONE WARS <i>(film)</i></b><br><br>
    			Star Wars: The Clone Wars is a 2008 American 3D animated epic military science fiction film directed by Dave Filoni, produced by Lucasfilm Animation, and distributed by Warner Bros. Pictures. The film is set in the Star Wars universe during the three-year time period between the films Star Wars: Episode II – Attack of the Clones (2002) and Episode III – Revenge of the Sith (2005). Set during the Clone Wars between the Galactic Republic and the Confederacy of Independent Systems, Jedi Knight Anakin Skywalker is assigned an apprentice, Ahsoka Tano. Jabba the Hutt enlists them to rescue his kidnapped son Rotta in exchange for an alliance. Anakin and Ahsoka track the kidnapper to a planet where they are ambushed by Count Dooku's apprentice Asajj Ventress and discover that Dooku hopes to frame the Jedi for Rotta's kidnapping.<br>

    			<iframe width="950" height="700" src="https://www.youtube.com/embed/Batyl_1dZlQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    		During the first year of the Clone Wars, Jedi Knights Anakin Skywalker and Obi-Wan Kenobi lead a small battalion of Republic Clone troopers against the Separatist droid army on the planet Christophsis. Awaiting reinforcements, the two Jedi greet a shuttle carrying the young Jedi Ahsoka Tano, who insists that she has been assigned by Jedi Master Yoda to serve as Anakin's Padawan. Anakin begrudgingly accepts Ahsoka's apprenticeship, and the two succeed in deactivating the Separatists' energy field while Obi-Wan stalls the droid army commander, allowing a Republic victory. Ahsoka earns Anakin's respect.<br>

Following the battle, Yoda arrives and informs the Jedi that crime lord Jabba the Hutt's son Rotta has been kidnapped. Anakin and Ahsoka are tasked with retrieving the Huttlet, while Obi-Wan is sent to Tatooine to negotiate with Jabba over a potential treaty between the Hutts and the Republic. Anakin and Ahsoka track the kidnapper and Rotta to the planet Teth, where they are ambushed by Separatist forces led by Count Dooku's apprentice Asajj Ventress, discovering that Dooku hopes to frame the Jedi for Rotta's kidnapping in order to get Jabba to ally with the Separatist army. The Jedi manage to escape the trap along with R2-D2 and hijack a derelict transport with which they travel to Tatooine. Obi-Wan, alerted by Anakin, arrives on Teth and defeats Ventress in a lightsaber duel, though she manages to escape.<br>

Meanwhile, Senator Padmé Amidala, secretly married to Anakin, learns of her husband's mission and fears for his safety. She decides to contact Jabba's uncle Ziro on Coruscant. The Hutt refuses to cooperate, apparently believing that it is the Jedi who are responsible for the situation. However, Padmé soon discovers that Ziro has actually conspired with Dooku to have Rotta killed for Jabba to have Anakin and Ahsoka executed in return, which will force the Jedi Council to take Jabba into custody and allow Ziro to seize power over the Hutt clans. Padmé is discovered and detained, but a chance call by C-3PO enables her to summon a squadron of clone troopers, and Ziro is arrested.<br>

Upon their arrival on Tatooine, Anakin and Ahsoka are shot down by MagnaGuards. Anakin devises a ruse to confront Dooku while carrying a decoy Rotta, leaving Ahsoka to take the real Rotta to Jabba's palace. While Anakin fights off Dooku, Ahsoka is ambushed by the MagnaGuards, whom she defeats. The two deliver Rotta safely to Jabba, who nonetheless orders the Jedi to be executed for their supposed kidnapping attempt. However, Padmé contacts Jabba in time and reveals Ziro and the Separatists' responsibility for the kidnapping. Acknowledging the Jedi's heroism and allowing the Republic to have Ziro punished for his betrayal, Jabba agrees to the treaty while Anakin and Ahsoka are retrieved by Obi-Wan and Yoda. In the meantime, during his escape, Dooku reports to his master Darth Sidious about the failure of their plot, but the Sith Lord assures him that the tide of war is still in their favor.
    		</p>
    	</div>
    </div>
    
<script type="text/javascript">
  function togglePopup(){
  document.getElementById("popup-1").classList.toggle("active");
}
</script>
</body>
</html>