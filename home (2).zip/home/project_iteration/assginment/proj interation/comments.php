<?php
date_default_timezone_set('America/Los_Angeles');
include 'dba.inc.php';
include 'comm.inc.php';
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="coms.css">
	<title>Comments</title>
</head>
<body>

<iframe width="850" height="500" src="https://www.youtube.com/embed/8939aURV9Dc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php
echo "<form method='POST' action='".setComment($conn)."'>
	<input type='hidden' name='cid' value='".$cid."'>
	<input type='hidden' name='uid' value='Anonymous'>
	<input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
	<textarea name='message'></textarea><br>
	<button type='submit' name='commentSubmit'>Comment</button>
</form>";

getCommments($conn);
?>
</body>
</html>