<?php
session_start();
if (!isset($_SESSION['username'])) {
  header('location:login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css/star.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/parallax.min.js"></script>
    <title>Series</title>
  </head>
  <body>
<header>
  <a href="mmain.php" class="rer"><img src="img/star wars.png" class="logo" alt="logo" style="width: 60px;
  height: 45px;"></a>
  <nav>
    <ul class="nav_links">
      <li><a href="films.php">Movies</a></li>
      <li><a href="films.php">Games</a></li>
    <li><a href="characters.php">Characters</a></li>
      <li><a href="#p1" class="add">Star Wars: A Clone Wars</a></li>
      <li><a href="#p2" class="add">Star Wars Rebels</a></li>
      <li><a href="#p3" class="add">The Mandalorian</a></li>
    </ul>
  </nav><div class="popup" id="popup-1" >
  <div class="overlay"></div>
  <div class="content">
    <div class="close-btn" onclick="togglePopup()">&times;</div>
    <h1 style="color:  #edf0f1;">About Us</h1>
    <p style="color:  #edf0f1;">Welcome to website about Star Wars, your number one source for all information about Star Wars Saga  .


Founded in 2020 by Asfandiyar Marat, Star Wars has come a long way from its beginnings in ASTANA IT UNIVERSITY. When Asfandiyar first started out, his passion for mat force be with you drove him to do tons of research so that Star Wars can offer you clear information about Skywalker Saga.</p>
  </div>
</div>

  <button onclick="togglePopup()">About us</button>

</header>


    <div class="parallax-window" data-parallax="scroll" data-z-index="1" data-image-src="https://imgix.bustle.com/uploads/image/2020/2/20/d36501bc-8892-42a2-93a4-72b38e2f4502-clone-wars-season-7.png">
<div class="container" id="p1"><p class="info" id="p1"><b>STAR WARS: A CLONE WARS<i>(serie)</i></b><br><br>
The Clone Wars (22-19 BBY), occasionally referred to as the Clone War, the Separatist War, or the Droid War, was a major, three-year war between the Galactic Republic and the Confederacy of Independent Systems. The war is named after the army of clone troopers used by the Republic against the Confederacy's battle droid army. With both being fielded in enormous numbers by each respective side, the Grand Army of the Republic and the Separatist Droid Army were two of the largest military forces in galactic history, and fighting between them swept through the galaxy upon the outbreak of war in 22 BBY.<br>

Prior to the conflict, Darth Sidious, under his alter ego Sheev Palpatine, had spent years amassing political power, eventually rising to become the Republic's Supreme Chancellor. Through his Sith apprentice Count Dooku, he sparked the Separatist Crisis, causing thousands of Republic star systems to secede and form a new government as the Confederacy, with Dooku as its Head of State. Beginning with the First Battle of Geonosis, the conflict quickly spread throughout the galaxy with both sides scoring significant victories. At different points in the war it seemed that either side was likely to triumph over the other. At the war's outset, both sides vied for control of major hyperspace lanes to gain strategic advantage. That particular struggle ended with a Republic victory when Jedi Knight Anakin Skywalker and his Padawan, Ahsoka Tano, secured an alliance between the Republic and the Hutt Clan.<br>

Battles, skirmishes, raids and other actions continued for the next two years, with notable battles occurring on Ryloth, Felucia, Malastare, and Kamino. During this time, the Separatists developed various super weapons, including more traditional weapons such as the ion cannons of the battleship Malevolence, as well as biological weapons such as a variant of the Blue Shadow Virus. Meanwhile the Republic launched several key offensives, including the Second Battle of Geonosis, which obliterated Geonosis' battle droid foundries; as well as a failed Jedi-led operation to capture Supreme Commander of the Droid Army General Grievous at Saleucami. Amidst the escalating conflict, many planets—including Mandalore and other members of the Council of Neutral Systems—struggled to maintain their neutrality, but found it difficult to escape the carnage.<br><iframe width="950" height="700" src="https://www.youtube.com/embed/kYeVbVBdbgw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br>

Over a year into the war, Republic Senator Padmé Amidala and Separatist Senator Mina Bonteri collaborated on an initiative to end the fighting. However, their collaboration ended after Dooku and Grievous' bombing of the Republic capital on Coruscant. Later, a peace conference on Mandalore also failed to resolve the conflict. With no end in sight, the Jedi worked with local militaries, including Mon Cala's military and Naboo's Gungan Grand Army, and covertly trained an insurgent rebel cell to retake Onderon from Separatists occupation. Similarly, the Confederacy relied upon factions such as the Umbaran Militia and the Zygerrian Slave Empire. Furthermore, a proxy war materialized when Mother Talzin and her son, Darth Maul, strove to exact their revenge on both the Sith and the Jedi.<br>

During the war's third and final year, the Republic drove the Separatists into redoubts within the Outer Rim Territories, initiating a campaign termed the Outer Rim Sieges. In an effort to reverse the course of the war, Grievous launched a massive strike on Coruscant through the Deep Core. Much of the Confederate fleet was lost in the assault, along with Head of State Count Dooku. The Confederacy quickly lost its core leadership in quick succession, with Grevious subsequently falling in battle during the Battle of Utapau, and the Separatist Council being massacred on Mustafar. This, coupled with the issuing of Order 66 and the deactivation of the droid army, led to the total capitulation of the Confederacy and, with it, an end to the war.<br>

Unbeknownst to most involved, the conflict was instigated, facilitated, and eventually resolved by Darth Sidious, whose ultimate goal was to restore the Sith Empire and to transform the Republic into the Galactic Empire with himself as Emperor, as well as the complete eradication of the Jedi Order. Evading arrest by Mace Windu and a cadre of Jedi, Sidious would succeed in this endeavor with the aid of Jedi Knight Anakin Skywalker, who Sidious seduced to the dark side of the Force and molded into his new apprentice Darth Vader. Sidious publicly branded the Jedi as traitors and triggered Order 66, which forced the Republic's clone troopers to betray and execute their Jedi Generals, thereby initiating a galaxy-wide Jedi Purge. Palpatine then declared an end to the Clone Wars in an extraordinary session of the Senate and proclaimed the transformation of the Republic into the First Galactic Empire, and the Galactic Senate into the Imperial Senate.
</p></div></div>
<div class="parallax-window" data-parallax="scroll" data-z-index="1" data-image-src="https://i0.wp.com/nerdvanamedia.com/wp-content/uploads/2016/06/star-wars-rebels-s2-bluray-homeent-tall.jpg?fit=1536%2C864&ssl=1">
  <div class="container">
  <p class="info" id="p2"><b>STAR WARS REBELS</b><br><br>
  Star Wars Rebels is an animated television series set during the time frame between the films Star Wars: Episode III Revenge of the Sith and Star Wars: Episode IV A New Hope. It premiered worldwide as a one-hour television movie, Star Wars Rebels: Spark of Rebellion, on Disney Channel on October 3, 2014; Regular episodes aired for four seasons on Disney XD, from October 13, 2014 to March 5, 2018. During its run, the series was nominated for four Emmy Awards, including two consecutive nominations for "Outstanding Children's Program."<br>

The series follows a motley group of rebels who live aboard the starship Ghost as they fight against the evil Galactic Empire. The rebels include Ezra Bridger, a young orphan from Lothal who learns he can use the Force; Kanan Jarrus, a Jedi who survived Order 66; Hera Syndulla, a Twi'lek pilot and veteran resistance fighter; Sabine Wren, a Mandalorian explosives expert; Garazeb "Zeb" Orrelios, a Lasat warrior; and the cantankerous astromech droid C1-10P, also known as Chopper. The crew will eventually help give rise to the Rebel Alliance.<br><iframe width="980" height="700" src="https://www.youtube.com/embed/n68knLlWz24" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
The series begins five years before Star Wars: Episode IV A New Hope, fourteen years into the reign of the Galactic Empire. The general premise is described as follows: "It is a dark time in the galaxy, as the evil Galactic Empire tightens its grip of power from world to world. As the series begins, Imperial forces have occupied a remote planet, ruling with an iron fist and ruining the lives of its people. But there are a select few who are brave enough to stand up against the endless Stormtroopers and TIE fighters of the Empire: the clever and motley crew of the starship Ghost. Together, this ragtag group will face threatening new villains, have thrilling adventures, and become heroes."<br></p>
</div></div>
<div class="parallax-window" data-parallax="scroll" data-z-index="1" data-image-src="https://images.wallpapersden.com/image/download/star-wars-the-mandalorian_66569_1920x1080.jpg">
  <div class="container">
    <p class="info" id="p3"><b>THE MANDALORIAN</b><br><br>
    After the stories of Jango and Boba Fett, another warrior emerges in the Star Wars universe. The Mandalorian is set after the fall of the Empire and before the emergence of the First Order. We follow the travails of a lone gunfighter in the outer reaches of the galaxy far from the authority of the New Republic<br>
    <iframe width="980" height="700" src="https://www.youtube.com/embed/XmI7WKrAtqs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
  After the stories of Jango and Boba Fett, another warrior emerges in the Star Wars universe. “The Mandalorian” is set after the fall of the Empire and before the emergence of the First Order. We follow the travails of a lone gunfighter in the outer reaches of the galaxy, far from the authority of the New Republic.</p>
  </div>
</div>
<script type="text/javascript">
  function togglePopup(){
  document.getElementById("popup-1").classList.toggle("active");
}
</script>
  </body></html>