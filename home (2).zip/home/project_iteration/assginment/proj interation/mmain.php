<?php
session_start();
if (!isset($_SESSION['username'])) {
  header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Star Wars</title>
	<link rel="stylesheet" type="text/css" href="css/mmain.css">
</head>
<body>
	<header>
  <a href="mmain.php"><img src="img/star wars.png" class="logo" alt="logo" style="width: 60px;
  height: 45px;"></a>
  <nav>
    <ol class="nav_links">
    <li><a href="films.php" class="ad">Movies</a></li>
    <li><a href="serials.php" class="ad">Series</a></li>
    <li><a href="star.php" class="ad">Games</a></li>
    <li><a href="characters.php" class="ad">Characters</a></li>
    <li><a href="login.php" class="ad">Account</a></li>
    <li><a href="logout.php" class="ad">Logout</a></li>
    <li><a href="comments.php" class="ad">Comments</a></li>
</ol>
  </nav>
<div class="popup" id="popup-1" >
  <div class="overlay"></div>
  <div class="content">
    <div class="close-btn" onclick="togglePopup()">&times;</div>
    <h1 style="color:  #edf0f1;">About Us</h1>
    <p style="color:  #edf0f1;">Welcome to website about Star Wars, your number one source for all information about Star Wars Saga.
Founded in 2020 by Asfandiyar Marat, Star Wars has come a long way from its beginnings in ASTANA IT UNIVERSITY. When Asfandiyar first started out, his passion for mat force be with you drove him to do tons of research so that Star Wars can offer you clear information about Skywalker Saga.</p>
  </div>
</div>
<button onclick="togglePopup()">About us</button>
  </header>
  <ul>
	<li><div class="content">
		<h2>Tatooine</h2>
		<p class="info">Tatooine was a sparsely inhabited circumbinary desert planet located in the galaxy's Outer Rim Territories. It was the homeworld to the influential Anakin and Luke Skywalker, who would go on to shape galactic history. Part of a binary star system, the planet was oppressed by scorching suns, resulting in the world lacking the necessary surface water to sustain large populations. As a result, many residents of the planet instead drew water from the atmosphere via moisture farms. The planet also had no natural surface vegetation.</p>
	</div></li>
	<li><div class="content">
		<h2>Hoth</h2>
		<p class="info">From space, the planet of Hoth looked like a pale blue orb due to its dense snow and ice covering. Five planets existed between Hoth and its sun, while an asteroid belt surrounded the planet with meteors occasionally striking the surface. Its surface was covered with glaciers and frozen ice plains. The temperature, although always frigid, was known to drop to -60°C come nightfall. Although devoid of intelligent life, Hoth was home to fifteen species of large gray snow lizards called tauntauns and to a species of towering predators known as wampas</p>
	</div></li>
    <li><div class="content">
		<h2>Bespin</h2>
		<p class="info">Bespin was an immense gas giant located in the vicinity of the Anoat system, a desolate sector of the galaxy. Bespin had several moons, and its gaseous mass contained a thin stratum of habitable atmosphere. Its layers were a source of rare Tibanna gas, which was harvested and refined in several mining complexes, including Cloud City, an opulent metropolis suspended in the planet's huge billowing clouds. The Ugnaught city of Ugnorgrad also was located over the planet, being ruled by King Ozz in the time after the Battle of Endor. During the Galactic Civil War, Bespin remained unaffiliated, but that did not prevent the Galactic Empire from garrisoning the planet and seizing Cloud City. </p>
	</div></li>
    <li><div class="content">
		<h2>Alderaan</h2>
		<p class="info"> Alderaan, located in the Core Worlds, was a terrestrial planet covered with mountains. During the waning decades of the Galactic Republic, it was ruled by Queen Breha Organa and represented in the Galactic Senate by her husband, Senator Bail Organa.

Following the rise of Sheev Palpatine's Galactic Empire, Alderaan played a pivotal role in the establishment of the Rebel Alliance, a movement that sought to restore the Old Republic's values. Because of its ties with the Alliance, the planet was destroyed when Grand Moff Wilhuff Tarkin decided to test the superlaser of the Death Star, a moon-sized battle station developed by the Empire, at full strength.</p>
	</div></li>
    <li><div class="content">
		<h2>Coruscant</h2>
		<p class="info">Coruscant, also known as Imperial Center during the rule of the Galactic Empire, was an ecumenopolis—a city-covered planet, collectively known as Galactic City— in the Coruscant system of the Core Worlds. Though debated by historians, it was generally believed that Coruscant was the original homeworld of humanity. In addition, Coruscant's strategic location at the end of several major trade routes enabled it to grow in power and influence, causing the city-planet to surpass its early rivals and become the hub of galactic culture, education, finance, fine arts, politics and technology. It was the location of several major landmarks, including the Jedi Temple, Monument Plaza and the Senate Building.</p>
	</div></li>
</ul>
	
<script type="text/javascript">
  function togglePopup(){
  document.getElementById("popup-1").classList.toggle("active");
}
</script>
</body>
</html>