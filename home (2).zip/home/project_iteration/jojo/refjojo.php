<?php
$db_host="localhost";
$db_name ="jotaro";
$db_user ="asfa";
$db_pass = "uXLB5ClvBvnaFdig";
$conn = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
if (mysqli_connect_error()){
    echo mysqli_connect_error();
}else{
    echo "connected successfully";
}
?>
