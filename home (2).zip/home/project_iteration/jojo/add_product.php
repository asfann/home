<?php
require 'refjojo.php';
if($_SERVER["REQUEST_METHOD"]=="gPOST"){
$sql = "INSERT INTO kujo(product_name,price)
VALUES ('".$_POST['product_name']."',
        '".$_POST['price']."')";
        $res = mysqli_query($conn,$sql);
        if($res==false){
        echo mysqli_error($conn);
        }else{
            $id=mysqli_insert_id($conn);
            echo "Data inserted with id: ".$id;
        }

}?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<header>
    <h1>Products</h1>
</header>
<main>
    <form method="post">
        <input type="text" name="product name" id="product_name"><br>
        <input type="number" name="price" id="price"><br>
        <button>save</button>
    </form>
</main>
</body>
</html>
