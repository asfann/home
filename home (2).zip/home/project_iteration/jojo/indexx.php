<?php
require "refjojo.php";
$sql="SELECT * FROM kujo";
$res=mysqli_query($conn,$sql);
if($res==false){
    echo mysqli_error($conn);
}else{
    $kujo = mysqli_fetch_all($res,MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en" dir="itr">
<head>
    <meta charset="utf-8">
    <title></title>
</head>
<body>
<header>
    <h1>My Blog</h1>
</header>
<main>
    <ul>

        <?php foreach ($kujo as $joj):?>
            <li style="list_style:none;">
                <h2><?=$joj["product_name"]?></h2>
                <p><?=$joj["price"]?></p>
            </li>
        <?php endforeach;?>
    </ul>
</main>
</body>
</html>
