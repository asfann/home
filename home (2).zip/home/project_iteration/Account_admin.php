<!Doctype html>
<html>
<head>
        <title>Account-SpaceX Store</title>
        <style>
            @import url('https://fonts.googleapis.com/css?family=Quicksand&display=swap');
@import url('https://fonts.googleapis.com/css?family=Lato&display=swap');
*{
    margin: 0;
    padding: 0;
    outline: none ;
}
body, html{
    width: 100%;
    height: 800px ;
  
}

body{
    background-color: white;
    text-align: center;
    font-family: Trebuchet MS, Helvetica;
}
         /* Navigation bar */
header{
   
    width: 100%;
    height: 50px;
    position: fixed;
    background-attachment: fixed;
    border-bottom: 2px solid silver;
    background-color: black;
    z-index: 100;
}

header #logo a{
    color: white;
    float: left;
    height: 30%;
    cursor: pointer;
    font-size: 1.7em;
    line-height: 45px;
    margin-left: 40px;
    font-family: 'Quicksand', sans-serif;  
    text-align: center;
    text-decoration: none;
}



#about{
    float:right;
    width: 60%;
   text-align: right;
    font-size: 1.3em;
    line-height: 40px;
    margin-bottom:10px;
    margin-top: 5px;
    font-family: 'Quicksand', sans-serif; 
}
#about>a{
    color:#fff;
    margin-right: 7%;
    
}

#about>a:not(#account){
    text-decoration: none;
}


#about>a:hover{
    color:#b0b0b0b0;
    text-decoration: underline;

}


#reviews{
    padding-top:10%;
}

#blog{
padding-left: 20%
}

#span{
    font-size:3.5em
}

}
        </style>
        
    </head>    
    <body>
        <header>
          
            <div id="logo">
                <a href="SpaceX.html" target="_blank">SpaceX</a></div>

        <div id="about">
            <a href="men.html" >MENS</a>
            <a href="Women.html"  >WOMENS</a>
            <a href="kid.html" >KIDS</a>
            <a href="accs.html" >ACCESSORIES</a>
            <a href="account.php">ACCOUNT</a>
          
        </div>
    </header>
    <?php

require 'database.php';

$sql = "SELECT*FROM review";
$res = mysqli_query($conn,$sql);
if($res===false){
   echo mysqli_error();
}else{
   $review = mysqli_fetch_all($res,MYSQLI_ASSOC);
}
?>
       
    <main id="reviews">
    
            <span id="span">Reviews</span>
            <br><br><br><br>
       <div id="blog">  <?php foreach($review as $article): ?><table>
            <tr>
                <td><h1>Review <?=$article['id'];?><h1></td>
            </tr>
            <tr>
           <td>  <h3> Name:</h3></td>
                <td>  <h3>  <?=$article['Name'];?></h3></td>
            </tr>
            <tr>
                <td>  <h3>Email:</h3></td>
                <td>  <h3>  <?=$article['Email'];?></h3></td>
            </tr>
         
            <tr>
                <td>  <h3>Message:</h3></td>
                <td>  <h3>  <?=$article['Message'];?></h3></td>
            </tr> 
           
        </table><br><br>
        <?php endforeach;?>  </div>

    </main>
</body>
<html>