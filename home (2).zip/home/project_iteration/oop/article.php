<?php
  require 'includes/database.php';
  require 'includes/article.php';
  $articles = getArticle($conn,$_GET['id']);
  require 'includes/header.php';
 ?>
 <?php if($articles===null): ?>
   <h2>No article has been found</h2>
<?php else: ?>
  <article >
    <h2><?=$articles['title']?></h2>
    <p><?=$articles['content']?></p>
    <p><?=$articles['publish_date']?></p>
  </article>
  <a href="edit_article.php?id=<?=$articles['id']?>">Edit</a>
  <form action="delete_article.php?id=<?=$articles['id']?>" method="post">
    <button>DELETE</button>
  </form>
<?php endif;
require 'includes/footer.php'; ?>
