<?php
require 'includes/database.php';
require 'includes/article.php';
require 'includes/header.php';
$articles = getArticle($conn,$_GET['id']);
 ?>
<form  method="post">
  <input type="text" name="title"><br>
  <textarea name="content" rows="4" cols="40"></textarea><br>
  <input type="date" name="publish_date"><br>
  <button>SAVE</button>
</form>
<?php
require 'includes/footer.php';
  if($_SERVER['REQUEST_METHOD']=='POST'){
    $id = $_GET['id'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $date = $_POST['publish_date'];
    $sql = "UPDATE articles SET title='$title',
            content = '$content',
            publish_date = '$date'
            WHERE id = '$id'";
    $res = mysqli_query($conn,$sql);
    if($res===false){
      echo mysqli_error($conn);

    }else{
      header("Location: article.php?id=$id");
    }
  }
?>
