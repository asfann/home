<?php
//$db_host = 'localhost';
//$db_name = 'blog_website';
//$db_user = 'it1908';
//$db_pass ='JvOyytYLrxpjXlEK';
//$conn = mysqli_connect($db_host,$db_user,$db_pass,$db_name);
//if(mysqli_connect_error()){
//  echo mysqli_connect_error();
//}else{
//  echo "Connected successfully"."<br>";
//}


class dbh{
    private $host;
    private $dbname;
    private $user;
    private $pass;
    protected function connect(){
        $this->host = 'localhost';
        $this->dbname = 'blod_website';
        $this->user = 'it1908';
        $this->pass = 'JvOyytYLrxpjXlEK';
 $conn = new mysqli($this->host,$this->dbname,$this->user,$this->pass);
        if(mysqli_connect_error()){
            echo mysqli_connect_error();
        }else{
            echo 'connect succesfully';
        }
    }

}
 ?>
