<?php
require 'includes/database.php';
if ($_SERVER["REQUEST_METHOD"]=="POST") {
  $sql = "INSERT INTO articles(title,content,publish_date)
          VALUES ('".$_POST['title']."',
                  '".$_POST['content']."',
                  '".$_POST['publish_date']."')";
  $res = mysqli_query($conn,$sql);
  if($res===false){
    echo mysqli_error($conn);
  }else{
    $id = mysqli_insert_id($conn);
    echo "Inserted with id:$id";
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <header>
      <h1>My Blog</h1>
    </header>
    <main>
      <form  method="post">
        <input type="text" name="title"><br>
        <textarea name="content" rows="4" cols="40"></textarea><br>
        <input type="date" name="publish_date"><br>
        <button>SAVE</button>
      </form>
      <a href="index.php">MAIN</a>
    </main>

  </body>
</html>
