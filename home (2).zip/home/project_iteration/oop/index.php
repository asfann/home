<?php
  require 'includes/database.php';
//
//  $sql = "SELECT * FROM articles";
//  $res = mysqli_query($conn,$sql);
//  if($res===false){
//    echo mysqli_error($conn);
//  }else{
//    $articles = mysqli_fetch_all($res,MYSQLI_ASSOC);
//  }
//  require 'includes/header.php';


class User extend dbh{
    protected function getUsers(){
        $sql = "SELECT * FROM user";
        $res = $this->conn()->query($sql);
    if($res === false){
        echo mysqli_error($conn);
    }else {
        $users = mysqli_fetch_all($res, MYSQLI_ASSOC);
    }
    }
}
 ?>

       <ul>
         <?php foreach ($articles as $article):?>
           <li style="list-style:none;">
             <h2><a href="article.php?id=<?=$article['id'];?>"><?=$article['title'];?></a></h2>
             <p><?=$article['content'];?></p>
             <p><?=$article['publish_date'];?></p>
           </li>
         <?php endforeach; ?>
       </ul>
       <a href="add_post.php">Add post</a>
<?php require 'includes/footer.php'; ?>
