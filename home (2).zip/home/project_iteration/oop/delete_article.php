<?php
require 'includes/database.php';
require 'includes/article.php';

$article = getArticle($conn, $_GET['id']);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $id = $article['id'];
  $sql = "DELETE FROM articles
        WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt === false) {

        echo mysqli_error($conn);

    } else {

        mysqli_stmt_bind_param($stmt, "i", $id);

        if (mysqli_stmt_execute($stmt)) {

            header("Location:index.php");

        } else {

            echo mysqli_stmt_error($stmt);

        }
    }
  }

 ?>
