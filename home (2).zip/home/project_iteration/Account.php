<!DOCTYPE html>
<html>
    <head>
        <title>Account-SpaceX Store</title>
        <style>
            @import url('https://fonts.googleapis.com/css?family=Quicksand&display=swap');
@import url('https://fonts.googleapis.com/css?family=Lato&display=swap');
*{
    margin: 0;
    padding: 0;
    outline: none ;
}
body, html{
    width: 100%;
    height: 800px ;
  
}

body{
    background-color: white;
    text-align: center;
    font-family: Trebuchet MS, Helvetica;
}
         /* Navigation bar */
header{
   
    width: 100%;
    height: 50px;
    position: fixed;
    background-attachment: fixed;
    border-bottom: 2px solid silver;
    background-color: black;
    z-index: 100;
}

header #logo a{
    color: white;
    float: left;
    height: 30%;
    cursor: pointer;
    font-size: 1.7em;
    line-height: 45px;
    margin-left: 40px;
    font-family: 'Quicksand', sans-serif;  
    text-align: center;
    text-decoration: none;
}



#about{
    float:right;
    width: 60%;
   text-align: right;
    font-size: 1.3em;
    line-height: 40px;
    margin-bottom:10px;
    margin-top: 5px;
    font-family: 'Quicksand', sans-serif; 
}
#about>a{
    color:#fff;
    margin-right: 7%;
    
}

#about>a:not(#account){
    text-decoration: none;
}


#about>a:hover{
    color:#b0b0b0b0;
    text-decoration: underline;

}


#text{
  padding-top:300px;
}

#text h1{
    font-weight: bolder;
    font-size: 3em;
  
}

#text h3{
    color: rgb(138, 134, 134);
    font-size: small;
}

#btn{
    width: 300px;
    height: 30px;
    color: white;
    background-color: black;
    font-size: 1.5em;
    border: 2px solid black;
    margin-top: 20px;
    transition: 0.5s;
}

#btn:hover{
    border:2px solid black;
    color: black;
    background-color: white;
    cursor: pointer;
}

#acc{
    margin-top: 10px;
}
 
#acc h3{
    
    font-size: small;
}
#acc a{
    color: rgb(138, 134, 134);
    font-size: small;
    text-decoration:none;

}
#acc a:hover{
    color: black;
    cursor: pointer;
}
        </style>
        
    </head>
    <body>
        <header>
          
            <div id="logo">
                <a href="SpaceX.html" target="_blank">SpaceX</a></div>

        <div id="about">
            <a href="men.html" >MENS</a>
            <a href="Women.html"  >WOMENS</a>
            <a href="kid.html" >KIDS</a>
            <a href="accs.html" >ACCESSORIES</a>
            <a href="account.php">ACCOUNT</a>
          
        </div>
    </header>

   <div id="text"> <h1>LOGIN</h1>
    <br>
    <h3>PLease enter your e-mail and password:</h3>
</div>
<br>
<?php
require 'database.php';
$sql = "SELECT*FROM  users";
$res = mysqli_query($conn,$sql);
if($res===false){
   echo mysqli_error();
}else{
   $users = mysqli_fetch_all($res,MYSQLI_ASSOC);
}
if($_SERVER["REQUEST_METHOD"]=="POST"){
    foreach($users as $val){
        if($_POST['Email']==$val['email']){
            if($_POST['Password']==$val['pass']){
                echo "Access!";
                if($val['status']==1){
                    header('Location: Account_admin.php');
                    exit();
                }else{
                    header('Location: Account_page.php');
                    exit();
                }
            }
        }
    }
}
?>  
    <form method="POST">
    <input id="t" type="text" name="Email" placeholder="Email" style="width: 300px; height: 30px; "><br> <br>
    <input  type="password" name="Password" placeholder="Password" style="width: 300px; height: 30px; ">
    <center><input type="submit" value="LOGIN"></center>
    <div id="acc"><h3>Don`t have an account?  <a href="Account_new.php">Create one</a></h3></div>
</form>
</body>
</html>