<?php
   include('session.php');
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit post</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <style media="screen">
    .textdiv {
      margin: 100px;
      opacity: 1;
      color: black;
      border: white solid 3px;
      border-radius: 5px;
      display: flex;
      text-align: center;
      flex-direction: column;
      justify-content: space-around;
      height: 500px;
      padding: 10px;
      height: 70%;
    }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark fixed-top">
      <!-- Brand -->
      <a class="navbar-brand" href="mainpage.html"><img src="Logo..png" alt="" height="50px" ></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="firstpage.php">All blogs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="yourblogs.php">Here's your blogs</a>
          </li>

          <li class="nav-item dropdown" style="position: absolute; right: 15px;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo $login_session; ?>
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="logout.php">Log out</a>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <?php
    $ss = "Select Id from users where username = '".$login_session."'";
    $result = mysqli_query($db,$ss);
    $user_id = mysqli_fetch_all($result, MYSQLI_ASSOC);
    $temp = $user_id[0]['Id'];
    if($_SERVER["REQUEST_METHOD"] == "POST") {
      if(isset($_POST['post_name']) && isset($_POST['post_content'])){
        $name = $_POST['post_name'];
        $text = $_POST['post_content'];
            $sql1 = "Select post_id from post";
            $result = mysqli_query($db,$sql1);
            $count = mysqli_num_rows($result);
            $Id = $count+1;
            $sql = "INSERT INTO post (post_id, post_name, post_content, user_id)
            VALUES ('".$Id."', '".$name."', '".$text."', '".$temp."')";
            $res = mysqli_query($db, $sql);

            header("location:firstpage.php");
        }
      }
    mysqli_close($db);
    ?>

       <div class="textdiv">
         <form class="" action="" method="post">
           <input type="text" name="post_name" value="" placeholder="enter post name"><br>
           <textarea name="post_content" rows="8" cols="80"></textarea><br>
           <input type="submit" name="" value="submit">
         </form>

       </div>
  </body>
</html>
