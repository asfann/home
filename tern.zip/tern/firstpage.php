<?php
   include('session.php');
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>First Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <style media="screen">
    .textdiv {
      margin: 20px;
      opacity: 1;
      color: black;
      border: white solid 3px;
      border-radius: 5px;
      display: flex;
      text-align: center;
      flex-direction: column;
      justify-content: space-around;
      height: 500px;
      padding: 10px;
      height: 70%;
    }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark fixed-top">
      <!-- Brand -->
      <a class="navbar-brand" href="mainpage.html"><img src="Logo..png" alt="" height="50px" ></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="firstpage.php">All blogs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="yourblogs.php">Here's your blogs</a>
          </li>

          <li class="nav-item dropdown" style="position: absolute; right: 15px;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo $login_session; ?>
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="logout.php">Log out</a>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <div class="contentdiv">
      <?php
      $ss = "Select Id from users where username = '".$login_session."'";
      $result = mysqli_query($db,$ss);
      $user_id = mysqli_fetch_all($result, MYSQLI_ASSOC);
      ?>
      <h1>Posts</h1>
      <div class="" style="bottom:50px; left: 100px; margin: auto; position: fixed;">
        <form class=""  action="createpost.php" method="post">
          <input type="hidden" name="user_id" value="<?php echo $user_id[0]['Id']; ?>">
          <input type="submit"  name="" value="Create new post">
        </form>
      </div>

      <?php
          $sql_name = "SELECT * FROM post";
           $res = mysqli_query($db, $sql_name);
           if($res == false){
             echo mysql_error($db);
           }
           $cout = mysqli_fetch_all($res, MYSQLI_ASSOC);
        ?>
        <?php  foreach ($cout as $posts): ?>
          <?php $tid =  $posts['post_id'];?>
          <?php
          if($posts['user_id'] == $user_id[0]['Id']){
            $access = "submit";
          }else{
            $access = "hidden";
          } ?>
          <div class="textdiv" style="background-color: rgba(44, <?php echo 120 - $tid; ?>, <?php echo $tid*50+20; ?>, 0.6);">
            <?php
             ?>
            <h1><?php echo $posts['post_name'] ?></h1>
            <br>
            <p style="font-size: 30px;"><?php echo $posts['post_content'] ?></p>
            <form class="" action="edit_post.php" method="post">
              <input type="hidden" name="id" value="<?php echo $tid; ?>">
              <input type="<?php echo $access; ?>" value="Edit Post">
            </form>
          </div>

        <?php endforeach; ?>
    </div>
  </body>
</html>
