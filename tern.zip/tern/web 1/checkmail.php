<?php
if(isset($_POST['mail'])){
    require "link.php";
    $mailCheck = $_POST['mail'];
    $sql_check = "SELECT email FROM users WHERE email = '$mailCheck'";
    $result = $link->query($sql_check);
    if($result->num_rows > 0){
        echo "reserved";
    }
    else{
        echo "free";
    }
}
