<!DOCTYPE html>
<html>
<head>
	<title>Characters</title>
	<link rel="stylesheet" type="text/css" href="css/char.css">
</head>
<body><header>
	<a href="mmain.php"><img src="img/star wars.png" class="logo" alt="logo" style="width: 60px;
  height: 45px;">
  <nav>
    <ul class="nav_links">
      <li><a href="star.php">Games</a></li>
      <li><a href="serials.php">Series</a></li>
      <li>
      	<a href="films.php">Movies</a>
      </li>
    </ul>
  </nav><div class="popup" id="popup-1" >
  <div class="overlay"></div>
  <div class="content">
    <div class="close-btn" onclick="togglePopup()">&times;</div>
    <h1 style="color:  #edf0f1;">About Us</h1>
    <p style="color:  #edf0f1;">Welcome to website about Star Wars, your number one source for all information about Star Wars Saga.
Founded in 2020 by Asfandiyar Marat, Star Wars has come a long way from its beginnings in ASTANA IT UNIVERSITY. When Asfandiyar first started out, his passion for mat force be with you drove him to do tons of research so that Star Wars can offer you clear information about Skywalker Saga.</p>
  </div>
</div>
  <button onclick="togglePopup()">About us</button>
</header><br>
<div class="contain">
	<div class="box" >
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/6/6f/Anakin_Skywalker_RotS.png/revision/latest?cb=20130621175844"></div>
		<div class="cont">
			<h3>Anakin Skywalker</h3>
			<p style="font-size: 63%"> Skywalker was born  before moving to the Outer Rim planet Tatooine during the Age of the Republic. Although he had a mother, the slave Shmi Skywalker, the truth about his parentage was that Anakin had no father—leading Jedi Master Qui-Gon Jinn to suspect that Skywalker's conception was the work of the midi-chlorians. Recognizing the boy's unprecedented connection to the Force, Jinn was determined to see Skywalker trained as a member of the Jedi Order, the task of which ultimately fell to his Padawan Obi-Wan Kenobi following Jinn's death.

Over the next decade, Skywalker rose to become one of the strongest Jedi in galactic history. While he was both caring and compassionate, his fear of loss was ultimately the catalyst for his downfall. During the war, Skywalker trained a Padawan, Ahsoka Tano, who ultimately left the Jedi Order after she was framed for the terrorist attack on the Jedi Temple. The loss of Tano affected Skywalker on a personal level, causing him to feel more isolated and bitter towards the Jedi High Council. With the Clone Wars nearing conclusion, Skywalker succumbed to the temptations of the dark side, believing the Sith had the power to save the life of Senator Padmé Amidala, his secret wife. Christened "Darth Vader" by his new Master Darth Sidious, the newly-minted Sith Lord assaulted the Coruscant Jedi Temple, killing fully-trained Jedi and novice younglings alike.</p>
		</div>
	</div>

	<div class="box">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/4/48/3683533_280.jpeg/revision/latest/scale-to-width-down/340?cb=20190425202641&path-prefix=hu"></div>
		<div class="cont">
			<h3>Obi-Wan Kenobi</h3>
			<p style="font-size: 66%">was a Force-sensitive human male and a legendary Jedi Master and member of the Jedi High Council during the Fall of the Republic. During the Age of the Empire, he went by the alias of Ben Kenobi in order to hide from the regime that drove the Jedi to near extinction in the aftermath of the Clone Wars. A nobleman known for his skills with the Force, Kenobi trained Anakin Skywalker as his Padawan, served as a Jedi General in the Grand Army of the Republic, and became a mentor to Luke Skywalker prior to his death in 0 BBY.

Born on the planet Stewjon in 57 BBY, Kenobi was inducted into the Jedi Order at a young age and became the apprentice of Qui-Gon Jinn after completing his initial lessons under Grand Master Yoda. During the Invasion of Naboo in 32 BBY, Kenobi defeated the Sith Lord Darth Maul and was awarded the status of Jedi Knight. Kenobi also began training Anakin Skywalker, having promised his dying master that the boy would become a Jedi, but often had to rein in his adventure-seeking apprentice. Over the years, Kenobi became concerned that Skywalker's powers made him arrogant but also regarded him as a good friend and a brother, and ultimately believed that Skywalker was in fact the Chosen One destined to restore balance to the Force by destroying the Sith.</p>
		</div>
	</div><div class="box">
		<div class="imgBx"><img src="https://upload.wikimedia.org/wikipedia/ru/thumb/9/96/CGIYoda.jpg/220px-CGIYoda.jpg"></div>
		<div class="cont">
			<h3>Yoda</h3>
			<p style="font-size:57% " class="add">a Force-sensitive male being belonging to a mysterious species, was a legendary Jedi Master who witnessed the rise and fall of the Galactic Republic, followed by the rise of the Galactic Empire. Small in stature but revered for his wisdom and power, Yoda trained generations of Jedi, ultimately serving as the Grand Master of the Jedi Order. Having lived through nine centuries of galactic history, he played integral roles in the Clone Wars,  the galaxy was on the verge of civil war with entire star systems—led by Count Dooku, Yoda's one-time Padawan—threatening to secede from the Republic. Unable to defend the entire Republic on their own, the Jedi took command of the newly-formed Grand Army of the Republic, with Yoda himself leading an army of clone troopers against the Separatist Droid Army of the Confederacy of Independent Systems in the first battle of the Clone Wars. For three years Yoda led the Republic military's war effort as a Jedi General, determined to bring a swift and decisive end to the conflict, but his efforts were undermined by Darth Sidious, the Dark Lord of the Sith who conspired to destroy the Jedi and restore the Sith to power. After the Jedi Purge commenced, killing thousands of Jedi both on Coruscant and across the galaxy, Yoda confronted the self-declared Galactic Emperor but failed to cut short Sidious' reign and consequently retreated into exile, leaving the Sith Master to consolidate his power with a new apprentice, Darth Vader, at his side. His remaining years were spent living in isolation  until Anakin's son, Luke Skywalker sought out the legendary Grand Master in the hope of becoming a Jedi Knight. A year later, with his health rapidly declining, Yoda died of old age and became one with the Force.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://i.pinimg.com/originals/34/64/20/3464206e24f9158eeb49f5997873a5ac.jpg"></div>
		<div class="cont">
			<h3>Luke Skywalker</h3>
			<p style="font-size:57% "> a Force-sensitive human male, was a legendary Jedi Master who fought in the Galactic Civil War during the reign of the Galactic Empire. Along with his companions, Princess Leia Organa and Captain Han Solo, Skywalker served on the side of the Alliance to Restore the Republic—an organization committed to the downfall of Emperor Palpatine and the restoration of democracy. Following the war, Skywalker became a living legend, and was remembered as one of the greatest Jedi in galactic history.

The son of Jedi Knight Anakin Skywalker and Senator Padmé Amidala, Luke Skywalker was born along with his twin sister Leia. As a result of Amidala's death and Anakin's fall to the dark side of the Force, the Skywalker children were separated and sent into hiding, with Leia adopted by the royal family of Alderaan while Luke was raised by his relatives on Tatooine. Longing for a life of adventure and purpose, Skywalker joined the Rebellion and began learning the ways of the Force under the guidance of Jedi Master Obi-Wan Kenobi, whose first apprentice was Luke's own father. During the Battle of Yavin, Skywalker saved the Alliance from annihilation by destroying the Empire's planet-killing superweapon, the Death Star. He continued his training in the years that followed, determined to become a Jedi Knight like his father before him, and found a new mentor in Grand Master Yoda. After his master's death, Skywalker participated in the Battle of Endor, during which he confronted the Sith Lord Darth Vader, whom he learned was in fact his father, Anakin Skywalker. With Luke's help, Anakin returned to the light side of the Force by destroying the Emperor at the cost of his own life, fulfilling his destiny as the Chosen One.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://i.pinimg.com/originals/5f/86/a1/5f86a13e7b338f4931e0bcaa5f785c40.jpg"></div>
		<div class="cont">
			<h3>Qui-Gon Jinn</h3>
			<p style="font-size:58% "> a Force-sensitive human male, was a venerable if maverick Jedi Master who lived during the last years of the Republic Era. He was a wise and well-respected member of the Jedi Order, and was offered a seat on the Jedi Council, but chose to reject in order to follow his own path. Adhering to a philosophy centered around the Living Force, Jinn strove to follow the will of the Force even when his actions conflicted with the wishes of the High Council. After encountering Anakin Skywalker, Jinn brought him to the Jedi Temple on Coruscant, convinced he had found the Chosen One. His dying wish was for Skywalker to become a Jedi and ultimately restore balance to the Force.At the Temple, Jinn was adamant that Skywalker was the Chosen One and should, therefore, be inducted into the Jedi Order. Having inspected Skywalker for themselves, however, the High Council deemed him too old, emotional, and dangerously full of fear and anger. Jinn saw their decision as a temporary setback but was forced to set aside his plans for Skywalker in order to resolve the situation on Queen Amidala's homeworld. During the Battle of Naboo, Jinn and Kenobi confronted Darth Maul together. While they initially managed to fend off the Sith Lord's attacks, master and apprentice were eventually separated during the lightsaber duel, resulting in Jinn sustaining a mortal injury. Rushing to his master's aid, Kenobi fought and ultimately defeated the Dathomirian Sith but was unable to save Jinn. With his last breath, Jinn made Kenobi promise that he would take Skywalker as his apprentice. Having secured Kenobi's word, Jinn became one with the Force, dying with the certainty that he had found the prophesied Chosen One.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://qph.fs.quoracdn.net/main-qimg-53ab580134c1198ea850b0dfbc05791e.webp"></div>
		<div class="cont">
			<h3>Count Dooku</h3>
			<p style="font-size:65% ">a Force-sensitive human male, was a Jedi Master that fell to the dark side of the Force . After leaving the Jedi Order, he claimed the title Count of Serenno and, during the Clone Wars, served as Head of State of the Confederacy of Independent Systems. He was the second apprentice of Darth Sidious, the Dark Lord of the Sith whose plan to conquer the galaxy relied on Dooku leading a  secessionist movement against the Republic. As such, Dooku immersed himself in the dark side and worked tirelessly to advance his master's plans, but ultimately forgot that treachery was the way of the Sith. formed Republic Military invaded Geonosis. As leader of the Separatists, Dooku delegated military authority to a cadre of subordinates personally trained by himself, including General Grievous and Asajj Ventress. The Sith, however, remained faithful to Darth Bane's Rule of Two; and as such, Dooku was compelled to betray his disciple after Sidious became suspicious of his own apprentice's intentions.  Dooku ultimately remained beholden to his master's will. By the third year of the war, Dooku and Grievous succeeded in abducting Chancellor Palpatine from the Republic capital of Coruscant. During the ensuing Battle of Coruscant, he was confronted and defeated by the Jedi Knight Anakin Skywalker, who summarily executed the Count via beheading at the Chancellor's behest. </p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://i.pinimg.com/originals/36/4d/03/364d03a9747b410bd5ec88f98f8a1e01.jpg"></div>
		<div class="cont">
			<h3>Leia Organa-Solo</h3>
			<p style="font-size:57% ">a Force-sensitive human female, was an Alderaanian politician and military general whose career spanned several decades, from the reign of the Galactic Empire to the rise of the New Republic. Born under the name Leia Amidala Skywalker, she was the daughter of Jedi Knight Anakin Skywalker and Senator Padmé Amidala of Naboo. Through her adoptive parents, Senator Bail Organa and Queen Breha, she gained the title of princess of Alderaan. Noted for her fearlessness in battle and dedication to freedom, Organa was considered one of the greatest leaders in the Alliance to Restore the Republic.In the aftermath of the Battle of Endor, Organa began learning the ways of the Force as her brother Luke Skywalker's apprentice. Though she constructed her own lightsaber, Organa did not complete her training as a Jedi and instead resumed her political career. Organa also married the Corellian smuggler Han Solo, an event followed by the birth of their son, Ben Solo. As the years passed, Organa was sidelined by a new generation of political leaders in the Galactic Senate. As the First Order rose in place of the fallen Empire, Organa struck out on her own to oppose them as founder of the Resistance. Organa's personal life, however, was struck by tragedy. Ben, whom Organa's brother mentored as part of an initiative to restore the Jedi Order, turned to the dark side and became the First Order warlord Kylo Ren.

With the fall of the New Republic, large swathes of the galaxy fell to the forces of the First Order, which had been taken over by Organa's son in his capacity as the new Supreme Leader. During the last months of her life, Organa shared her knowledge of the Jedi ways with Rey, a scavenger from Jakku, and with her dying breath she reached out to Ben before becoming one with the Force. </p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://i.pinimg.com/originals/9c/b5/6b/9cb56b246ee654cdb4a98f82b327ab73.jpg"></div>
		<div class="cont">
			<h3>Darth Maul</h3>
			<p style="font-size:57% ">was a Force-sensitive Dathomirian Zabrak male and dark-side warrior who served as the apprentice Dark Lord of the Sith Darth Maul during the final years of the Galactic Republic and reigned as a crime lord during the rule of the Galactic Empire.He was taken at a young age by the Dark Lord of the Sith Darth Sidious, who anointed him his first Sith apprentice, Darth Maul. Through his training, Maul grew strong in the dark side of the Force, becoming an expert lightsaber duelist and assassin. During the crisis on Naboo, Maul confronted Jedi Master Qui-Gon Jinn and Padawan Obi-Wan Kenobi. Although he succeeded in killing the former, Maul was defeated and maimed by Jinn's apprentice, who left the Sith Lord for dead. As a result of Maul's defeat and apparent death, Sidious replaced him with Count Dooku.In the waning days of the Clone Wars, Maul escaped from Sidious and ultimately returned to Mandalore where he was overthrown by former Padawan Ahsoka Tano and an army of clone troopers. However, Maul survived the war and continued to build his own empire as a crime lord and the secret leader of Crimson Dawn. He was later stranded on the planet Malachor, where he hoped to destroy the Sith by unlocking the superweapon at the heart of the Sith temple. Maul's plan was thwarted by two Jedi,  Jarrus and Bridger, the latter of whom Maul hoped to corrupt as his own apprentice. After escaping Malachor, Maul continued to try to tempt Bridger to the dark side before ultimately learning that Kenobi was still alive in spite of Order 66. Seeking hope and purpose, Maul sought Kenobi on Tatooine. Maul engaged Kenobi in a brief lightsaber duel for the last time. Kenobi cut Maul's lightsaber in half and dealt Maul a lethal blow, ending Maul's decade-spanning quest for vengeance.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/disney/images/3/36/Kit-Fisto_profile.jpg/revision/latest?cb=20191023211616"></div>
		<div class="cont">
			<h3>Kit Fisto</h3>
			<p style="font-size: 70%">was a Nautolan Jedi Master during the last years of the Galactic Republic. He was among the Jedi who fought in the Battle of Geonosis and was one of the few survivors out of the 200 Jedi who fought in the battle.

He became a Jedi General of the Clone Army in the Clone Wars and took part in such conflicts as the Mission to Vassek 3 and the Battle of Mon Cala. He was also involved in a mission with his former Padawan Nahdar Vebb to capture the escaped prisoner, Nute Gunray—however, the two ended up facing the notorious Jedi hunter General Grievous inside his lair. While Vebb perished at the hands of the General, Fisto very nearly bested him in combat, and escaped with his life, but without Gunray, ultimately making the mission a failure. At some point during the Clone Wars, Fisto was accepted as a member of the Jedi Council.

While he was at the Jedi Temple, Anakin Skywalker revealed to Mace Windu that Chancellor Palpatine was a Sith Lord. Windu took Fisto, alongside Jedi Masters Agen Kolar and Saesee Tiin to Palpatine's office to arrest him. In the following duel, after Kolar and Tiin had perished, Fisto was killed by the Chancellor with Windu joining soon later.</p>
		</div>
	</div>

	<div class="boxx">
		<div class="imgBx"><img src="https://trinixy.ru/pics5/20151113/han_solo_01.jpg"></div>
		<div class="cont">
			<h3>Han Solo</h3>
			<p style="font-size:57% "> was a human male smuggler who became a leader in the Alliance to Restore the Republic and an instrumental figure in the defeat of the Galactic Empire during the Galactic Civil War. He hailed from Corellia and became a smuggler in the employ of Jabba the Hutt. He was husband of Princess Leia Organa, brother-in-law of Jedi Master Luke Skywalker, father of Ben Solo, rivals and close friends with fellow smuggler Lando Calrissian and best friends with the Chewbacca.His fortune seemed to have changed when he agreed to charter Luke Skywalker, Obi-Wan Kenobi, and the droids R2-D2 and C-3PO to Alderaan, but he became caught up in the rebellion against the Empire and, after helping Leia Organa escape from the Death Star, Solo fought with the Rebellion for a number of years afterward, taking part in numerous operations and battles against the Empire.He married Organa, and the two had a son, Ben Solo. The boy struggled with the dark side of the Force—like his mother, who was the daughter of Darth Vader and twin sister of Luke Skywalker, Ben was Force-sensitive—so Organa sent him to be trained as a Jedi by Skywalker. He was seduced to the dark side by Snoke.

Having lost their son, Solo left and returned smuggle until he was brought back into the fight by a scavenger named Rey and a defected First Order stormtrooper named Finn, who carried with them a droid, BB-8, that had part of a map to Skywalker's location. Solo, who retrieved the Falcon from Rey and Finn, returned to Organa, who led the Resistance against the First Order, and fought in the battle to destroy the First Order superweapon. During the battle, Solo saw his son, who had taken the name Kylo Ren, and tried to convince him to return home. Instead, Ren stabbed his father with his lightsaber. Mortally wounded, Solo fell to his death.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/star-wars-canon-extended/images/2/20/Plo_Koon1.jpg/revision/latest?cb=20170804034303"></div>
		<div class="cont">
			<h3>Plo Koon</h3>
			<p style="font-size:90% ">  was a Kel Dor Jedi Master serving as a member of the Jedi High Council during the last years of the Galactic Republic. He frequently undertook dangerous missions. He was the Jedi who found Ahsoka Tano, and from that moment, they shared a special bond. He was among the Jedi who participated in the Battle of Geonosis. He became a High Jedi General in the Clone Wars and took part in such conflicts as the Battle of Abregado and the Second Battle of Felucia. While he was leading a squadron of ARC-170 starfighters on Cato Neimoidia he was shot down and killed by his own troops after Emperor Darth Sidious executed Order 66.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/ru.starwars/images/5/55/%D0%A1%D0%B8%D0%BD%D0%B8%D0%B9_%D0%BC%D0%B5%D1%87_%D0%BD%D0%B0_%D1%81%D0%B8%D0%BD%D0%B5%D0%BC_%D1%84%D0%BE%D0%BD%D0%B5.JPG/revision/latest?cb=20140903130107"></div>
		<div class="cont">
			<h3>Shaak Ti</h3>
			<p style="font-size:75% "> was a Togruta Jedi Master and member of the Jedi High Council in the waning years of the Galactic Republic. During the Clone Wars, a galaxy-wide conflict between the Republic and the Confederacy of Independent Systems, Ti took part in the pivotal battles of Geonosis, Kamino, and Coruscant.

In addition to her role as a general for the Grand Army of the Republic, she personally oversaw the training and development of clone forces on Kamino. While in this role, she became entangled in a conspiracy surrounding the origins of the organic inhibitor chips placed in every clone, and the secrets being kept from the Jedi about them. During the Battle of Coruscant, Ti was sent to protect Supreme Chancellor Sheev Palpatine, but was knocked unconscious in a duel with Separatist General Grievous. As she meditated during the attack on the Jedi Temple, she was killed by Darth Vader, the fallen Jedi Anakin Skywalker.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://i.pinimg.com/originals/8e/14/21/8e1421336a6531c8e8e2a57a3560671d.jpg"></div>
		<div class="cont">
			<h3>Ki-Adi-Mundi</h3>
			<p style="font-size:80% ">a Force-sensitive Cerean male, was a Jedi Master and member of the Jedi High Council during the last years of the Galactic Republic. By the time of the Clone Wars, Mundi became a Jedi General of the Grand Army of the Republic. Like his Jedi colleagues, he led the Republic clone troopers against the Separatist Alliance forces in several battles across the galaxy, including the first and second campaign on Geonosis and the Outer Rim Sieges. In 19 BBY, the third and final year of the war, Mundi oversaw the Republic invasion of Mygeeto with the 21st Nova Corps under his command. During the campaign, Supreme Chancellor Sheev Palpatine instructed the Grand Army soldiers to execute their Jedi leaders in accordance with Order 66, an act which resulted in the death of Mundi along with the majority of the Jedi Order.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://images-na.ssl-images-amazon.com/images/I/71Fxh1Ld8vL._AC_SX425_.jpg"></div>
		<div class="cont">
			<h3>R2-D2</h3>
			<p style="font-size:58% "> was an R2 series astromech droid. A smart, spunky droid serving a multitude of masters over its lifetime, R2 never had a full memory wipe nor has he received new programming, with these factors resulting in an adventurous and independent attitude. Oftentimes finding himself in pivotal moments in galactic history, his bravery and ingenuity saved the galaxy time and time again.

Beginning his service in the employ of Queen Amidala of Naboo, the droid would wind up serving Jedi Knight Anakin Skywalker during the waning years of the Galactic Republic, often accompanied by the protocol droid C-3PO in many adventures throughout the Clone Wars. After his master's turn to the dark side of the Force, he would eventually serve Senator Bail Organa. Nineteen years following the death of the Galactic Republic, he would play a pivotal role in helping the Alliance to Restore the Republic destroy the Empire's dreaded Death Star, carrying technical readouts essential to its destruction. Serving Jedi Knight Luke Skywalker, the son of his two former masters throughout the Galactic Civil War, he would  witness the destruction of the Empire's dreaded Death Star a mere four years after the first space station's destruction.

	In the subsequent thirty years, Artoo would accompany Luke Skywalker until the destruction of his attempted resurrection of the Jedi Order. Following Luke's disappearance, Artoo set himself into a self-imposed low power mode as . Despite this, his celebrated role in the Rebellion protected him from the usual recycling procedure of many old droids, allowing him a peaceful semi-retirement in the Resistance as he pored over several decades of uninterrupted data.
</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://www.peoples.ru/character/movie/c-3po/c-3po_1.jpg"></div>
		<div class="cont">
			<h3>C-3PO</h3>
			<p style="font-size:57% "> was a 3PO unit protocol droid designed to interact with organics, programmed primarily for etiquette and protocol. He was fluent in over six million forms of communication, and developed a fussy and worry-prone personality throughout his many decades of operation. Along with his counterpart, the astromech droid R2-D2, C-3PO constantly found himself directly involved in pivotal moments of galactic history, and aided in saving the galaxy on many occasions.

C-3PO was rebuilt from spare parts by Anakin Skywalker. Shortly after the Clone Wars, C-3PO's memory was erased, though R2-D2's memory was not. C-3PO and R2-D2 were assigned to the Alderaan cruiser Tantive IV, where they served senator Bail Organa for nineteen years. At some point during this time, 3PO's right leg was fitted with mismatched plating.

They became embroiled in the Galactic Civil War when Leia Organa of the Rebel Alliance entrusted them to bring a copy of the Death Star plans to the Jedi Master Obi-Wan Kenobi on Tatooine. After meeting Skywalker's son, Luke and the smuggler Han Solo, the droids helped rescue princess Leia from the Empire's Death Star. They became directly attached to the three humans, helping them and their rebellion defeat the Empire and restore freedom to the galaxy, most notably when he convinced the Ewoks to aid the Rebels at the Battle of Endor.
About thirty years after the events on Endor, C-3PO was still an aide to Leia Organa, who had become a General in the Resistance, a private military group opposed to the First Order, a military junta that emulated the Old Empire. By that time, C-3PO's language database had been updated so that he could understand and communicate in over seven million different forms of communication, including ancient Sith dialects.</p>
		</div>
	</div>
	<div class="box">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/4/48/Chewbacca_TLJ.png/revision/latest/scale-to-width-down/500?cb=20190830144754"></div>
		<div class="cont">
			<h3>Chewbacca</h3>
			<p style="font-size: 57%"> known affectionately to his friends as Chewie, was a Wookiee warrior, smuggler, and resistance fighter who fought in the Clone Wars, the Galactic Civil War, and the conflict between the First Order and the Resistance. He hailed from the planet Kashyyyk and became a Wookiee military leader. During the Clone Wars, he was captured by Trandoshan slavers and held captive on Wasskah, but he worked with a fellow captive, Jedi Commander Ahsoka Tano, to escape. He later commanded Wookiee forces during the Battle of Kashyyyk alongside the Grand Army of the Republic, led by Jedi Master Yoda. During the battle, one of the last ones of the war, Yoda's clone troopers received Order 66 from Supreme Chancellor Palpatine and, with the help of Chewbacca, Yoda escaped Kashyyyk and the destruction of the Jedi Order.

In the years that followed, during the rule of the Galactic Empire, Chewbacca became a smuggler and the co-pilot of Captain Han Solo aboard the Millennium Falcon. They worked in the employ of crime lord Jabba until Solo was forced to dump a shipment of spice to avoid trouble with the Empire, at which point a bounty was placed on their heads. Soon thereafter, Chewbacca and Solo were hired by Jedi Master Obi-Wan Kenobi to ferry him, Luke Skywalker, C-3PO, and R2-D2 to Alderaan on a mission vital to the survival of the Alliance to Restore the Republic. After finding Alderaan was destroyed, the group was brought aboard the Death Star, where they helped Princess Leia Organa escape from captivity and return to the Rebel base. Though Chewbacca and Solo initially chose to leave Yavin 4 and not join the Rebellion, they ended up fighting in the Battle of Yavin and were instrumental in Skywalker's destruction of the Death Star, a major victory for the Rebellion.</p>
		</div>
	</div>

	<div class="box">
		<div class="imgBx"><img src="https://upload.wikimedia.org/wikipedia/en/thumb/4/4b/Jjportrait.jpg/220px-Jjportrait.jpg"></div>
		<div class="cont">
			<h3>Jar Jar Binks</h3>
			<p style="font-size: 57%">was a Gungan male military commander and politician who played a key role in the Invasion of Naboo and the Clone Wars that culminated in the fall of the Galactic Republic and the rise of the Galactic Empire. Once an outcast from Gungan society due to his clumsy behavior, he regained favor with his people by helping secure an alliance between the Gungan boss Rugor Nass and Queen Padmé Amidala of Naboo, an alliance vital in ending the Trade Federation's invasion of their shared homeworld. In the years that followed, Binks became a Junior Representative for his people in the Galactic Senate, serving alongside Amidala once she became the planet's senator.

Ten years after the Naboo Crisis, growing tensions between the Galactic Republic and the Confederacy of Independent Systems threatened an outbreak of full-scale galactic war. In the absence of Senator Amidala, whose life was under threat by Separatist assassins, Binks was convinced by Supreme Chancellor Sheev Palpatine to propose that the chancellor receive emergency executive powers to raise a Grand Army of the Republic. The proposal passed, leading to the outbreak of the Clone Wars, during which time Binks participated in a number of diplomatic missions for the Galactic Senate.

The emergency powers Binks proposed were ultimately used by the chancellor, secretly the Sith Lord Darth Sidious, to amass total power and transform the Republic into the Empire. In the years that followed, Binks once again became an outcast on Naboo due to his role in the rise of the Empire. By the time of the Battle of Jakku, Binks was a street performer in the capital city of Theed, where he was scorned by adults but beloved by the children who came to watch his antics</p>
		</div>
	</div><div class="box">
		<div class="imgBx"><img src="https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/returnofthejedi-landocalrissian.jpg"></div>
		<div class="cont">
			<h3>Lando Calrissian</h3>
			<p style="font-size:59% "> was a human male smuggler, gambler, and card player who became Baron Administrator of Cloud City and, later, a general in the Rebel Alliance. He was the owner of the Millennium Falcon before losing it to Han Solo in a game of sabacc on Numidian Prime. After losing the Falcon, Calrissian put an end to his days as a smuggler and became an entrepreneur, setting up a small mining operation on the planet Lothal before eventually becoming the leader of Cloud City in the skies of the planet Bespin.

During the Galactic Civil War, Darth Vader arrived on Cloud City in order to lay a trap for his son, Luke Skywalker. As part of the trap, the Dark Lord of the Sith forced Calrissian into tricking a group of Rebels, including Solo and Princess Leia Organa, leading them to Vader himself. Though Vader promised to leave Cloud City without an Imperial presence, Calrissian felt the deal had been altered to the point where he could no longer tolerate it. Calrissian alerted his citizens to the Galactic Empire's presence and impending occupation, and he ordered an evacuation. He helped the Rebels try to rescue Solo, who had been frozen in carbonite, from Boba Fett, but the bounty hunter escaped.

Calrissian joined the Rebel Alliance and set out to find Solo. After locating him in the palace of Jabba the Hutt on Tatooine, Calrissian aided in his rescue. The Rebels returned to the fleet and Calrissian became a general, volunteering to lead the assault on the DS-2 Death Star during the Battle of Endor. During the battle, he piloted the Millennium Falcon into the battle station's core, firing the shot which destroyed it.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/Asajj-Ventress-700x409.jpg"></div>
		<div class="cont">
			<h3>Asajj Ventress</h3>
			<p style="font-size:65% ">was a Dathomirian female who, at various points throughout her life, was a slave, a Jedi Padawan, an assassin of the Sith, a Nightsister and a bounty hunter. In the final decades of the Galactic Republic's reign, Ventress was born into a clan of Force-sensitive Nightsister witches led by Mother Talzin on the planet Dathomir. Early in her life, her coven was forced to surrender Ventress to the criminal Hal'Sted, who spirited Ventress away from her sisters to the war-torn world of Rattatak where she was raised as a slave in his service. She was orphaned when her master was killed by Weequay pirates, but was later discovered by the Jedi Knight Ky Narec, who was stranded on Rattatak and waging a battle against the pirate marauders. Narec raised Ventress and taught her to use the Force in the ways of the Jedi Order, and together they protected the people of Rattatak and fought back against the predatory attacks of pirates and warlords. After a decade of helping the local population, Ventress was orphaned once more when Narec was killed by pirates seeking to end the Jedi's crusade on their world. Enraged by the loss and bereft of guidance, Ventress embraced the dark side of the Force, deposing the local warlords and ruling in their stead. She was eventually discovered by the Sith Lord Count Dooku and fell under his guidance and tutelage as a dark acolyte and aspiring apprentice.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://swmodel.ru/wp-content/uploads/2012/06/hMEZszqF-720.jpg"></div>
		<div class="cont">
			<h3>Grievous</h3>
			<p style="font-size:57% ">was a Kaleesh male warlord who served as a commanding officer in the military forces of the Confederacy of Independent Systems during the last years of the Galactic Republic.  Noted for his ruthlessness and extensive cybernetic enhancements, Grievous inspired fear as he traveled across the galaxy, invading entire worlds.

Grievous sustained severe injuries that required extensive repair by the time of the Clone Wars. Willingly submitting to a procedure that rendered him more mechanical than organic, he became a living weapon, granting him lightning-quick reflexes and devastating strength. Although he was neither Jedi or Sith, nor even sensitive to the power of the Force, Grievous was a skilled lightsaber duelist, having trained in the art of the lightsaber under the fallen Jedi Master-turned-Sith Lord Count Dooku. Grievous killed Jedi over the course of the war, and would claim their lightsabers both as trophies and weapons to be used against other opponents, be they Jedi or clone troopers.

In addition to his combat skills, Grievous was a brilliant military strategist who oversaw multiple campaigns throughout the Clone Wars.Grievous launched a daring raid on Coruscant, the Republic capital world, resulting in the abduction of Supreme Chancellor Sheev Palpatine. However, the Jedi succeeded in rescuing the Chancellor. Following the loss of Dooku, Grievous and his army went into hiding in the Outer Rim Territories. The Sith Lord Darth Sidious, betrayed the general's location to the Jedi Order, allowing them to invade the planet Utapau in an effort to bring a swift and decisive conclusion to the war. As a result, Grievous was ultimately slain by his nemesis, Jedi General Obi-Wan Kenobi.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/f/f9/Aayla.jpg/revision/latest?cb=20120815094201"></div>
		<div class="cont">
			<h3>Aayla Secura</h3>
			<p style="font-size: 63% ">a Force-sensitive Rutian Twi'lek female, was a Jedi Master who served as a Jedi General of the Grand Army of the Republic during the Clone Wars. Prior to the Clone Wars, Secura learned the ways of the Force as the Padawan of Jedi Master Quinlan Vos. With the outbreak of civil war between the Galactic Republic and the Confederacy of Independent Systems, Secura and her fellow Jedi supported the Republic by becoming officers in its newly-formed military. As a general, she commanded the clone troopers of the 327th Star Corps, with Commander CC-5052 "Bly" serving at Secura's side.

Throughout the conflict, Secura fought alongside her soldiers in multiple battles across the galaxy, from Geonosis to Quell, Coruscant, and Felucia. As the war drew to an end, the clones were instructed by Supreme Chancellor Sheev Palpatine to execute Order 66, resulting in a sudden purge of the Jedi Order at the hands of their own troopers. As a result, Secura was among the first casualties of the purge, having been shot in the back repeatedly by Bly and several other clone troopers.

The demise of Secura and many other Jedi was sensed through the Force by Grand Master Yoda, who survived the purge and ultimately escaped into exile, while the Galactic Empire rose to power in place of the Republic. Secura's death was also witnessed in a Force vision by Depa Billaba and her apprentice, Caleb Dume on Kaller. </p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://cdn.vox-cdn.com/thumbor/_3sxdcRY2QVXlvtFzm9QbU8XTDA=/0x0:2770x1166/1200x800/filters:focal(1668x327:2110x769)/cdn.vox-cdn.com/uploads/chorus_image/image/66532457/Screen_Shot_2020_01_22_at_9.38.17_AM.0.png"></div>
		<div class="cont">
			<h3>Ahsoka Tano</h3>
			<p style="font-size:58% ">nicknamed "Snips" by her Master and known as "Ashla" after the Clone Wars, was a Jedi Padawan who, after the conflict, helped establish a network of various rebel cells against the Galactic Empire. A Togruta female, Tano was discovered on her homeworld of Shili by Jedi Master Plo Koon, who brought her to the Jedi Temple on Coruscant to receive Jedi training. Following the outbreak of the Clone Wars, Jedi Grand Master Yoda assigned the young Tano to be the Padawan learner of Jedi Knight Anakin Skywalker, whom she joined at the Battle of Christophsis. Whereas Tano was eager to prove herself, Skywalker had a reputation for recklessness, and they had a rather difficult start as Master and apprentice. Yet, they worked together to rescue Rotta, the son of crime lord Jabba Desilijic Tiure, and returned Rotta to his father, thus facilitating a crucial alliance between the Hutt Clan and the Galactic Republic.
			After the Galactic Empire came to power, Tano went into hiding on Thabeska and Raada. Following the evacuation of Raada, Tano joined Senator Bail Organa's growing rebel movement. She became the manager of his intelligence network and adopted the codename "Fulcrum." As Fulcrum, Tano provided intelligence to various rebel factions including Hera Syndulla's Spectres rebel cell.  In addition, Tano's efforts against the Empire brought her into contact with the Dark Lord of the Sith Darth Vader, who, unknown to her, was actually her former master, Anakin Skywalker, as well as the Imperial Inquisitors known as the Fifth Brother and the Seventh Sister. Following the mission to Malachor, Tano became lost to the rubble during a duel with Darth Vader.
</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://pm1.narvii.com/6200/525a277434fa37c88689250e83655575101443d4_hq.jpg"></div>
		<div class="cont">
			<h3>Jango Fett</h3>
			<p style="font-size:57% ">was a human male bounty hunter and mercenary who lived during the final years of the Galactic Republic, allegedly hailing from the planet Concord Dawn. In addition to the sleek armored suit that concealed his scarred face, Fett possessed an arsenal of weaponry, including dual  blaster pistols, a jetpack with a built-in missile launcher, and other exotic tools such as Kamino saberdart. Known for his proficiency in marksmanship and unarmed combat, he was regarded as the best hunter in the galaxy by the time of the Separatist Crisis.

Although Fett wore Mandalorian armor, the government of Mandalore saw him as nothing more than a common mercenary with no actual ties to the Mandalorians. Nevertheless, his reputation attracted the attention of the Sith as they plotted their return to galactic power and ties to the Warrior culture are ambiguous at best. When the Sith Lord Count dooku approached him with an offer to become the template of an army of clone troopers, Fett agreed to be cloned on one condition: an unaltered clone would be created for him to raise as his "son." That clone was Boba Fett who, unlike the clone troopers, was neither conditioned for obedience nor modified to age at an accelerated rate. In the days leading to the first battle of the Clone Wars, Fett was hired by Viceroy Nute Gunray to assassinate his political nemesis, Senator Padmé Amidala of Naboo. He failed in his commission, however, and was subsequently tracked to the Kaminoan homeworld by the Jedi Knight Obi-Wan Kenobi, forcing Fett to return to his Sith benefactor on Geonosis. Fett served as Count Dooku personal bodyguard during the battle between the Jedi Order and the Separatist Droid Army, but he was no match in battle against Jedi Master Mace Windu, who decapitated the bounty hunter with his  lightsaber. 
</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://www.denofgeek.com/wp-content/uploads/2019/11/star-wars-boba-fett-facts.jpg?fit=1800%2C1012"></div>
		<div class="cont">
			<h3>Boba Fett</h3>
			<p style="font-size: 62%">was a clone of Jango Fett, the human male bounty hunter . With his customized Mandalorian armor, deadly weaponry, and the fearsome starship, Boba carried on his "father's" legacy by becoming one of the most feared bounty hunters in the galaxy, during the reign of the Galactic Empire. Trained in combat and martial skills from a young age, he became a legend over the course of his career, which included contracts for the Empire and the criminal underworld.

The orphaned Fett grew up in the company of criminals during the Clone Wars. He joined the crew of Aurra Sing, hoping the ruthless bounty hunter would help him exact revenge against Windu. Their plot ultimately ended in failure, leading to a brief stint in prison after which Fett struck out on his own, working as a bounty hunter alongside the likes of Bossk and Dengar. Over the years, Fett was employed as a mercenary by crime lords as well as the Sith. During the Galactic Civil War, he successfully tracked the Millennium Falcon to Bespin for the Sith Lord Darth Vader, who allowed the bounty hunter to take Captain Han Solo to the Hutt gangster Jabba . A year later, the Alliance to Restore the Republic attempted to rescue Solo on Tatooine, where they fought against the Hutt's mercenaries, including Fett, above the Great Pit of Carkoon. During the battle, Solo accidentally slammed a pole into Fett's jetpack, igniting it and causing the bounty hunter to tumble into the man-eating sarlacc pit.</p>
		</div>
	</div>

	<div class="boxx">
		<div class="imgBx"><img src="https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/palpatine-family-children-1576775874.jpg?crop=0.488xw:0.976xh;0.512xw,0&resize=480:*"></div>
		<div class="cont">
			<h3>Palpatine</h3>
			<p style="font-size:57% "> was a Force-sensitive Human male who served as the last Supreme Chancellor of the Galactic Republic and the first Emperor of the Galactic Empire. A Dark Lord of the Sith in the Order of the Sith Lords, recorded by history as the most successful who had ever lived, his deeds resulted in overthrow the ancient Republic and the noble Jedi Order from within. Noted for his sadistic and self-serving intentions just as well as his ability to conceal them, Palpatine impacted the galaxy perhaps more than any other single individual, and it is likely that his impact on history, for good or ill, is immeasurable.

Born  on the planet Naboo to the aristocratic House Palpatine, Palpatine discovered the Sith at a young age as a collector of dark side artifacts.  he met Hego Damask, a Muun businessman who was in reality the Sith Lord Darth Plagueis. Under Plagueis's manipulation, Palpatine killed his father and pledged himself to his new Master's dark side teachings as Darth Sidious. Palpatine lived a double life for many years, serving an untarnished career as Naboo's ambassador in the Galactic Senate while learning from his master and training a young Zabrak as the Sith assassin Darth Maul. Plagueis and Sidious, both exceptionally skilled and powerful in the Force, were able to conceal their identities from the Jedi for decades. As Plagueis privately searched for the key to eternal life, Sidious manipulated galactic politics, culminating in the blockade of Naboo by the Trade Federation. In the wake of the political crisis, the Galactic Senate voted to elect him as Supreme Chancellor, and around the same time, in accordance with Bane's Rule of Two, Sidious murdered Plagueis and usurped the role of Sith Master.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://cdnb.artstation.com/p/assets/images/images/023/499/081/large/fito-barraza-darth-sidious-1400px.jpg?1579411226"></div>
		<div class="cont">
			<h3>Darth Sidious</h3>
			<p style="font-size:59% ">   a Force-sensitive human male, was the Dark Lord of the Sith and Galactic Emperor who ruled the galaxy from the fall of the Galactic Republic to the fragmentation of the Galactic Empire. Rising to power in the Galactic Senate as Senator Sheev Palpatine, he was elected to the office of Supreme Chancellor and, during the Clone Wars, accumulated wartime powers in the name of security. As the Emperor, he dropped the facade, no longer needing to cultivate two identities, and henceforth ruled as Darth Sidious in thought and action, though he was known by many as just the Emperor. His machinations brought an end to the last era of peace in galactic history, replaced a millennium of democracy with New Order fascism, and restored the Sith to power through the destruction of the Jedi Order.
			The Emperor ruled the galaxy for a generation with Darth Vader as his last apprentice. His reign remained relatively unchallenged until the formation of the Alliance to Restore the Republic which, in turn, began the Galactic Civil War in 0 BBY. After the Death Star was destroyed, the Emperor sensed a disturbance in the Force and foresaw Luke Skywalker's potential to destroy him. During the construction of a new Death Star, the Emperor manipulated Skywalker into a confrontation with Vader, believing the Jedi aspirant could be turned like his father before him. However, the Emperor was confounded by Skywalker's refusal to join the Sith, causing Sidious to torture the young Jedi Knight with Force lightning. Affected by his son's compassion, Vader sacrificed his life by destroying the Emperor, and thus fulfilled his destiny as the Chosen One.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/ru.starwars/images/e/ed/Snoke_TLJ.png/revision/latest?cb=20180224160016"></div>
		<div class="cont">
			<h3>Snoke</h3>
			<p style="font-size:61% ">
Secretly an artificial creation of Darth Sidious, Snoke was engineered on Exegol, a legendary Sith-affiliated planet hidden in the Unknown Regions, where loyalists of the Sith Eternal awaited the return of the Sith. In the years following the collapse of the Galactic Empire, Snoke gained command of the technological war machine that the First Order engineered to destroy the New Republic and General Leia Organa's Resistance. Snoke also sought to finish the destruction of the Jedi Order, and as such, he directed his apprentice to locate and kill Jedi Master Luke Skywalker.

After the New Republic fell in 34 ABY, Snoke oversaw the conquest of the galaxy from his headquarters aboard the First Order flagship Supremacy. Having lured the Jedi apprentice Rey to him through her bond with Ren, Snoke urged the Ren to complete his training by executing her. Ren turned on Snoke, however, using Skywalker's lightsaber to end his master's life. Ultimately, Snoke's entire existence was built for this moment: to serve as a final test for Ren. He not only tested Ren's worthiness as a disciple, but also his capacity to inherit the Sith legacy. His role had been designed by the Sith Eternal cultists to act as a final crucible, to groom and mold Ren into a master of attack and cunning. Ren became the new Supreme Leader of the First Order, but after encountering a revived Sidious on Snoke's homeworld of Exegol, he aspired to rule the galaxy as Emperor of the Final Order.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/star-wars-episode-9-rise-of-skywalker-rey-1580293398.jpg?crop=0.436xw:0.652xh;0.256xw,0.0873xh&resize=480:*"></div>
		<div class="cont">
			<h3>Rey Skywalker</h3>
			<p style="font-size:57% ">was a Force-sensitive human female who, after years of living as a scavenger, became a Jedi during the war between the First Order and the Resistance.  Rey ultimately chose the Jedi path, despite inheriting her strength in the Force from a Dark Lord of the Sith. 

Born during the New Republic Era, Rey's parents left her on the planet Jakku in hopes of keeping her safe from the Emperor. Toughened by her travails in the deserts of her homeworld, Rey became a skilled mechanic, pilot, and combatant during her time as a scavenger. Having sided with the Resistance, Rey formed new friendships with Finn, a renegade stormtrooper, as well as the veterans Han Solo and Chewbacca, drawing her deeper into the galactic war that ensued from the destruction of the New Republic. In the course of her journey Rey located the legendary Jedi Master Luke Skywalker who, despite his self-imposed exile on Ahch-To, trained her in the ways of the Jedi Order. After Skywalker sacrificed his life to save the Resistance, Rey assumed his mantle as the last Jedi and became the apprentice of General Leia Organa.

It was through Ren that Rey discovered her origins as the Emperor's granddaughter, and upon confronting Palpatine in person, she was nearly swayed to the dark side of the Force. Rey was saved, however, by a redeemed Ben Solo, who ultimately renounced the dark persona of Kylo Ren. Aided by the spirits of all the Jedi, Rey died vanquishing her dark grandfather, causing Solo to make the ultimate sacrifice in order to bring Rey back to life.  Although Solo was supposedly the last of the Skywalker bloodline, Rey assumed the name "Skywalker" to honor their memory, repudiating her own heritage as a Palpatine.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://www.ecopetit.cat/wpic/mpic/65-659897_star-wars-the-last-jedi-finn-uhd-4k.jpg"></div>
		<div class="cont">
			<h3>Finn</h3>
			<p style="font-size:58% ">aa Force-sensitive human male stormtrooper who served the First Order until his desertion and subsequent defection to the Resistance during the First Order–Resistance war. Though trained since birth to be a loyal and obedient soldier, Finn conscience conflicted with the methods of the First Order. For a time he was unwilling to support the Resistance, hoping to escape the galactic conflict instead of fighting for a cause he believed was doomed to fail. As the galaxy became consumed by war, the renegade trooper was ultimately forced to decide where his true loyalties lay.
Born during the New Republic Era, Finn was part of a new generation of stormtroopers—human children conscripted into the military forces of the First Order—modeled on the Republic clone troopers and Imperial stormtroopers of the past. He originally trained with Batch Eight before joining the FN Corps, a sub-branch of the Stormtrooper Corps, and although his potential was recognized by his commanding officers, Finn lacked the ruthlessness that had become common in the ranks under the influence of Captain Phasma. In the waning days of the cold war, he hesitated to kill civilians during his first mission and consequently decided to desert after witnessing the massacre of Tuanul. Lacking experience as a pilot, Finn freed a Resistance prisoner, Commander Poe Dameron, who coined the nickname "Finn" to supplant the renegade stormtrooper's alphanumeric designation. He then sought his own freedom while forming friendships with the Jakku scavenger Rey and the droid BB-8, as well as the Rebel war heroes Han Solo and Chewbacca.
</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://lumiere-a.akamaihd.net/v1/images/poe-main_611e1021.jpeg?region=0%2C0%2C1280%2C640"></div>
		<div class="cont">
			<h3>Poe Dameron</h3>
			<p style="font-size:57% "> was a human male who originally served as a member of the Spice Runners of Kijimi, before becoming a pilot in the New Republic and eventually joining the Resistance, rising to become acting General of the Resistance, during its conflict and subsequent war with the First Order. The son of Lieutenant Shara Bey and Sergeant Kes Dameron of the Alliance to Restore the Republic, Dameron followed in his late mother's footsteps in becoming a pilot, serving the New Republic Defense Fleet as the commander of Rapier Squadron, but grew disillusioned with the Republic's inaction to the First Order's violations of the Galactic Concordance. Dameron defected to the Resistance, where he became one of General Leia Organa's most trusted operatives. Dameron flew under the callsign of Black Leader while piloting his specialized T-70 X-wing starfighter, Black One.

As the conflict with the First Order grew more desperate, Dameron was sent to find Lor San Tekka on Jakku, who had part of a map to locate Organa's brother, Jedi Master Luke Skywalker. Though Dameron entrusted the map to his astromech droid BB-8, he was captured by the First Order and interrogated for the location of the map, eventually being forced to hand over the information. He escaped with the help of a defecting stormtrooper, whom Dameron nicknamed Finn, and returned to the Resistance base on D'Qar on his own. He aided Finn, Rey, Han Solo, and Chewbacca with air support during the Battle of Takodana, and he later flew during the battle to destroy the superweapon known as Starkiller Base. During the battle, after the base was damaged by Solo, Finn, Rey, and Chewbacca, Dameron fired the shots that destroyed the Starkiller weapon, saving the Resistance from certain destruction.</p>
		</div>
	</div>
	<div class="box">
		<div class="imgBx"><img src="https://images3.alphacoders.com/100/1003732.jpg"></div>
		<div class="cont">
			<h3>Darth Vader</h3>
			<p style="font-size: 61%"> After assassinating the leaders of the Confederacy of Independent Systems, Vader was confronted on Mustafar by his one-time friend and mentor, Kenobi, resulting in a lightsaber duel that left Vader burned and mutilated. As a consequence of his defeat, he was rebuilt as a cyborg and encased in a life-sustaining suit of armor, further distancing the persona of Vader from that of Anakin Skywalker. In addition, Amidala's death in childbirth broke the fallen Jedi Knight's heart, leaving him more machine than man mentally as well as physically.

Throughout the Dark Times, the former Anakin Skywalker brought fear to the galaxy in his capacity as the Emperor's dark enforcer. However, in spite of his deep immersion in darkness, Vader never succeeded in fully killing the side of himself that was Skywalker. His confrontation with his son, the aspiring Jedi Knight Luke Skywalker, during the Galactic Civil War awoke the compassion within the Sith Lord, causing Vader to renounce his allegiance to the Sith in order to save Luke from the Emperor's wrath. By killing his master, however, Vader sustained critical damage to his armor, making death inevitable. Resigned to his fate, his dying wish was to see his son with his own eyes for the first and final time. In the end, he died not as Darth Vader but as Anakin Skywalker, the Chosen One who brought balance to the Force by destroying the Sith. His destiny fulfilled, Skywalker's consciousness was able to endure beyond death due to his sacrifice and redemption, allowing him to live on in spirit alongside his deceased Jedi mentors, Obi-Wan Kenobi and Grand Master Yoda.</p>
		</div>
	</div>

	<div class="box">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/zlodei/images/8/88/Commander_Cody.jpeg/revision/latest?cb=20140628074022&path-prefix=ru"></div>
		<div class="cont">
			<h3>CC-2224</h3>
			<p style="font-size: 57%">nicknamed "Cody," was a clone trooper officer who held the military rank of Marshal Commander in the Grand Army of the Republic during the Clone Wars. Additionally, he served as the commanding officer of the renowned 7th Sky Corps and personally led the 212th Attack Battalion. A natural and practical leader, Commander Cody was the second-in-command of Jedi General Obi-Wan Kenobi, to whom he was particularly loyal. A capable strategist and an exceptional soldier on the battlefield, his qualities earned him the respect of both his Jedi officer and his fellow clone troopers.

Following the first battle of the Clone Wars, Cody and his fellow clones deployed across the galaxy to defend the Republic against the secessionist Confederacy of Independent Systems. They also often served alongside the elite 501st Legion; Commanded by Jedi General Anakin Skywalker, Kenobi's former Padawan, and Clone Captain CT-7567 "Rex," a friend of Cody.

The Jedi High Council assigned the 212th Attack Battalion, the task of ending the war by destroying General Grievous. Having tracked the Supreme Commander of the Separatist Droid Army to the planet Utapau with the help of Clone Intelligence, Cody and his troops engaged the battle droids while Kenobi confronted Grievous. In the midst of the Battle of Utapau, which continued to rage even after Grievous' demise, Supreme Chancellor Sheev Palpatine instructed Cody to execute Order 66 secret protocol calling for the destruction of the Jedi Order. Despite their friendship, mutual respect and camaraderie, Cody's loyalty to Kenobi was overridden by his programming as a clone. He, therefore, obeyed the chancellor and attempted to execute his former friend. </p>
		</div>
	</div><div class="box">
		<div class="imgBx"><img src="https://i.pinimg.com/originals/92/cc/da/92ccda21a7e5cc44d8398ed8a601173c.jpg"></div>
		<div class="cont">
			<h3>Rex</h3>
			<p style="font-size:61% ">designation CT-7567, was a veteran Clone Captain and Advanced Recon Commando who commanded Torrent Company, a company of clone troopers within the Grand Army of the Republic's famed 501st Legion during the Clone Wars. Rex later served as a captain and commander within the Alliance to Restore the Republic during the Galactic Civil War. Rex participated in many battles over the course of the Clone Wars. As the captain of the 501st, Rex served as second-in-command to Jedi General Anakin Skywalker, whose bravery and unconventionality in battle he came to share. In addition to being a close friend of Skywalker he also became friends with Skywalker's apprentice, Ahsoka Tano. He was close with Marshal Commander Cody, with their relationship mirroring that of their respective Jedi Generals, Skywalker and Obi-Wan Kenobi, whom Rex was also well acquainted with. Rex and his companions often worked together during the front-line campaigns against the Confederacy of Independent Systems.

Throughout his career, Rex proved to be an effective leader who truly cared for the men under his command, even as he began to doubt his own future—and those of his clone brethren—in the Republic.   Rex's faith in the Republic was sorely tested by events such as the framing of Tano and the murder of his long-time comrade Fives, who had gone rogue after unearthing an anti-Jedi directive that had been bred into all of the Republic's clone troopers.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://www.iphones.ru/wp-content/uploads/2015/09/bfe.jpg"></div>
		<div class="cont">
			<h3>BB-8</h3>
			<p style="font-size:68% ">sometimes spelled and pronounced Beebee-Ate and nicknamed BB, was a BB-series astromech droid who operated approximately thirty years after the Battle of Endor. It had a dome head, similar to that of R2 series astromech droids, with the bulk of its body made up of a ball on which the droid's head rolled. BB-8 was mostly white, with some silver and orange on its body, as well as a black photoreceptor. The droid belonged to Resistance pilot Poe Dameron, whom he accompanied during his flights on his T-70 X-wing starfighter.A BB-series astromech droid who operated, BB-8 became the companion of the New Republic Commander and flight leader of Rapier Squadron, Poe Dameron. During one of Rapier Squadron's routine patrols in the Mirrin sector, BB-8 and Poe's squadron responded to a distress message from the freighter Yissira Zyde, which had been boarded and hijacked by the First Order, a remnant of the Old Empire. Rapier Squadron failed to stop the First Order from escaping with the Yissira Zyde and its cargo of high-capacity charging areas. One of the Rapier pilots Muran was killed when the hyperspace wave generated by the Yissira Zyde slammed into his T-85 X-wing.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/9/94/Galen_Erso_SWI170.png/revision/latest/scale-to-width-down/500?cb=20170127052459"></div>
		<div class="cont">
			<h3>Galen Walton Erso</h3>
			<p style="font-size:85% "> was a human male scientist and leading galactic authority on crystallography and energy enrichment. Born on the planet Grange, an agricultural backwater world, Erso was drafted into the Republic Futures Program, where his skill and intelligence ultimately led him to becoming a critical component, though reluctant, in the development of the DS-1 Orbital Battle Station. In doing so, Erso managed to subtly sabotage its design in a way that ultimately proved disastrous for the Galactic Empire.

One of the most renowned polymaths in the galaxy, Galen was a gifted theoretician, mathematician, and experimental physicist. Galen was a recipient of the Kuat Systems Engineering Medal, the Ashgad Prize and the Roche Foundation Prize.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://www.usajacket.com/wp-content/uploads/2016/11/Star-Wars-Jones-Jyn-Erso-Jacket-%E2%80%93-Vest.jpg"></div>
		<div class="cont">
			<h3>Jyn Erso</h3>
			<p style="font-size:58% ">was a human female soldier and former criminal who became a pivotal member of the Alliance to Restore the Republic when she led Rogue One in stealing the Death Star plans during the Battle of Scarif. She was the daughter of Lyra Erso, a devout member of the Church of the Force, and scientist Galen Erso, who was forced into helping the Galactic Empire build the Death Star. Erso's mother was killed when Director Orson Krennic, the commander of the Death Star project, kidnapped her father—who affectionately referred to his daughter as "Stardust." She was raised by resistance fighter Saw Gerrera and became a child soldier in his army.

After being abandoned by the Partisans, Erso spent several years on her own, committing a number of crimes in order to survive in a dangerous galaxy.She was recruited by the Rebel Alliance to find Gerrera on Jedha, where he had information about Galen and the Death Star project. She found a holographic recording of her father who confirmed the existence of the Death Star and that the plans kept on Scarif would reveal a fatal weakness he planted in its design. She attempted to save her father on Eadu, but he was killed. With little support from the Rebel Alliance, Jyn and Captain Cassian Andor led a squad, Rogue One, to Scarif where they stole the plans from the Imperial security complex. She transmitted the plans to the Alliance Fleet that arrived in orbit, but the Death Star soon fired on Scarif in an attempt to eliminate the Rebel threat. Erso and Andor were the last surviving members of their squad, and they died when the blast reached the complex.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://images.hdqwalls.com/download/kylo-ren-4k-new-oz-1336x768.jpg"></div>
		<div class="cont">
			<h3>Ben Solo</h3>
			<p style="font-size:56% "> was a Force-sensitive human male Jedi who, after falling to the dark side of the Force, eventually renounced his adopted persona of Kylo Ren and was redeemed. During the New Republic Era, he conquered much of the galaxy as Supreme Leader of the First Order and master of the Knights of Ren. The blood of the most powerful Jedi and Sith flowed through his veins, granting him raw strength in the Force. Ren embodied the teachings of both sides, creating much conflict within him, yet it was through discord that he derived power, and he learned to channel his anger into strength. Ultimately, Ren sought to build an immunity to the light side of the Force and destroy the last remnants of the Jedi Order, fulfilling the legacy of his grandfather—the Sith Lord Darth Vader.

The man who became known as the "Jedi Killer" was born on the planet Chandrila,when the Galactic Empire surrendered to the New Republic. The son of General Han Solo and Princess Leia Organa, Ben Solo was trained by his uncle, Jedi Master Luke Skywalker. After the destruction of Skywalker's Jedi temple, Solo renounced his family and assumed the identity of Kylo Ren, becoming a First Order warlord and the apprentice of Supreme Leader Snoke. Ren's descent into darkness was marked by the massacre of civilians and the murder of his father, but the act of patricide failed to end his inner turmoil. 

Supreme Leader Ren prioritized the destruction of the Resistance and the capture of Rey, viewing both as obstacles in his path to complete domination. The war came to a head  with the return of the Sith Lord Darth Sidious, who urged Ren to become the new Emperor by killing Rey. However, the persona of Kylo Ren ceased to exist after his mother died, allowing him to regain his former identity as Ben Solo. After the battle on Exegol, Solo sacrificed himself to revive Rey.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://i.ytimg.com/vi/8n7sqDvy3Pc/maxresdefault.jpg"></div>
		<div class="cont">
			<h3>Saw Gerrera</h3>
			<p style="font-size:58% ">was a human male Onderonian resistance fighter who, as a leading member of the Onderon rebels, fought against the Confederacy of Independent Systems on Onderon during the Clone Wars. He and his younger sister, Steela Gerrera, were instrumental in the rebel liberation of their homeworld during the Onderonian Civil War. He later became a key member in the fight against the Galactic Empire and the formation of the Alliance to Restore the Republic. His tactics against the Empire led him to be seen as an extremist, one whose notoriety was recognized by the Empire and, many years later, the New Republic.At the end of the Clone Wars, the Republic was transformed into the Galactic Empire. Later, Saw brought Galen Erso, Lyra Erso, and Jyn Erso to the uninhabited planet of Lah'mu. When Orson Krennic took Jyn's parents away from her, Saw found her and raised her until she was a young adult. Gerrera fought against the Imperial Military and led a resistance group known as the Partisans, a militant organization that some considered an extremist organization with terrorism tactics. His resistance cell, a continuation of his Onderonian resistance, was one of the first in the group of cells that formed the Rebel Alliance. He was later involved in the early campaigns of the Rebel Alliance, by which time his more-extreme tactics had come to stand in stark contrast with those of Alliance leaders Bail Organa and Mon Mothma. He eventually based his group on Jedha, where he met Jyn again. When Jedha City was destroyed by the Death Star, Saw told Jyn he was done running and stayed on Jedha, and was killed by the aftermath of the blast.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://lumiere-a.akamaihd.net/v1/images/chirrut-imwe_5ed7457a.jpeg?region=255%2C0%2C1305%2C654"></div>
		<div class="cont">
			<h3>Chirrut Îmwe</h3>
			<p style="font-size: 100%">was a blind human born on the moon Jedha in 52 BBY. One of the Guardians of the Whills, an order of spiritual warrior-monks, he was active during the days of the Galactic Empire and worked as an itinerant preacher in Jedha City. Alongside his close friend, partner, and protector, Baze Malbus, Îmwe became part of a volunteer group of Rebels tasked with stealing the plans of the first Death Star. Îmwe died during the Battle of Scarif in 0 BBY after assisting Jyn Erso and Cassian Andor in breaking into the Imperial archives.</p>
		</div>
	</div>

	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/5/5b/Cal_Profile.png/revision/latest/scale-to-width-down/500?cb=20190615064800"></div>
		<div class="cont">
			<h3>Cal Kestis</h3>
			<p style="font-size:57% "> was a Force-sensitive human male who became a Jedi Knight during the reign of the Galactic Empire. As one of the few remaining Jedi who survived the purge that all but destroyed the Jedi Order, Kestis lived in seclusion for years until a confrontation with the Inquisitorius compelled him to openly resist the Empire's rule. Hunted across the galaxy by the Empire's Jedi hunters, Kestis embraced his connection to the Force once more, having decided to restore the Jedi Order.

As the Padawan of Jedi Master Jaro Tapal, Kestis served alongside his mentor in the Clone Wars until the Grand Army of the Republic betrayed their Jedi officers, having received the command to execute Order 66 from Supreme Chancellor Sheev Palpatine. As a result, the clone troopers of the 13th Battalion attempted to execute Kestis as a traitor to the Galactic Republic, forcing General Tapal to sacrifice himself in order to save his apprentice. After his master's death, Kestis lived in exile on the planet Bracca, working as a rigger for the Scrapper Guild until he was discovered by the Second Sister and the Ninth Sister.

Kestis joined the crew of the starship Stinger Mantis after they rescued him from the Inquisitors. Over the course of their journey, Kestis befriended the droid BD-1, the former Jedi Cere Junda, the Mantis' captain Greez Dritus, and the Nightsister Merrin. They attempted to locate Eno Cordova's Jedi holocron, which contained information that was vital to creating a new generation of Jedi. Though they retrieved the holocron while surviving an encounter with the Sith Lord Darth Vader, Kestis chose to destroy the holocron in order to protect the galaxy's Force-sensitive children from the Sith. By then, Kestis had been recognized as a fully-trained Jedi by his new mentor Junda.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://i.pinimg.com/originals/30/c9/dd/30c9dd0a797f893caa00da295e64f352.jpg"></div>
		<div class="cont">
			<h3>Ewoks</h3>
			<p style="font-size:85% ">  were a diminutive species of furry bipeds native to the forest moon of Endor. They were most notable for helping the Rebel Alliance defeat the forces of the Galactic Empire at the Battle of Endor, allowing the shield generator there to be destroyed, and in turn, the DS-2 Death Star.

Ewoks were individuals that stood about one meter tall. They used spears, slings, and knives as weapons; they also used hang gliders as vehicles. Although skilled in forest survival and the construction of primitive technology, the Ewoks had yet to progress past stone-level technology when discovered by the Empire. They were quick learners, however, when exposed to advanced technology with simple mechanical processes and concepts.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://cdn.gamestatic.net/files/editor_uploads/Plohoymnu/%D0%B1%D0%B41.jpg"></div>
		<div class="cont">
			<h3>BD-1</h3>
			<p style="font-size:65% "> The BD unit designated BD-1 was an exploration droid. The masculine-programmed droid accompanied Jedi Master Eno Cordova on the Jedi's journey to explore the history of the Zeffo. Cordova later realized that they were in danger, and programmed BD-1's memory to be blocked, only revealed by someone the droid trusts.

BD-1 then remained on Bogano in the vicinity of the Zeffo Vault until the Padawan Cal Kestis, a survivor of Order 66, arrived on the planet at the behest of Cere Junda in order to find a holocron key to rebuilding the Order. Kestis quickly gained the support of BD-1, and they entered the vault. Along the way, the droid's scomp link was broken by the local wildlife. Unable to unlock the deepest reaches, Kestis took the droid back to his starship and crew, the Stinger Mantis.

They then traveled to other worlds on their quest to uncover the secrets of the Vault and that of the Zeffo. BD-1 scanned other Zeffo artifacts, showing recordings of Cordova to Kestis. When they are confronted on Zeffo by the Second Sister, BD-1 activated a force field between the combatants, saving Kestis' life. During their journey, Kestis upgraded the droid and repaired the scomp link.

During their exploration of Zeffo, Kestis was stunned by a Haxion Brood droid bounty hunter. BD-1 and the Padawan were imprisoned on Ordo Eris. Kestis broke them both out, and were rescued by the Mantis.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/star-wars-canon-extended/images/7/7b/Cere_Junda.jpg/revision/latest?cb=20191228213025"></div>
		<div class="cont">
			<h3>Cere Junda</h3>
			<p style="font-size:95% ">a Force-sensitive human female, was a former Jedi Knight and Seeker, who mentored Padawan Cal Kestis in the ways of the Force during the rise of the Galactic Empire. At one time, she served as the Padawan of Jedi Master Eno Cordova before taking Trilla Suduri as her apprentice. In the aftermath of Order 66, Junda severed her connection to the Force and disappeared into hiding, while Suduri fell to the dark side and joined the Imperial Inquisitorius. Determined to overthrow the regime that all but annihilated her fellow Jedi, Junda dedicated herself to the secret restoration of the Jedi Order.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/b/bd/Trilla-JFO.png/revision/latest/scale-to-width-down/500?cb=20200222170758"></div>
		<div class="cont">
			<h3>Trilla Suduri</h3>
			<p style="font-size:55% ">  formerly known as the Second Sister, was a Force-sensitive human female who served in the Inquisitorius during the reign of the Galactic Empire. Trained in the Jedi arts, Suduri was an expert lightsaber duelist and one of the Empire's deadliest Jedi hunters. However, Suduri's strongest asset was her brilliant intellect, being able to anticipate the behavior of her prey.

Suduri was once a Jedi who learned the ways of the Force under the Jedi Knight Cere Junda. In the aftermath of the Clone Wars, Suduri and Junda sought to hide from the newly-risen Empire while protecting a group of Jedi younglings. Ultimately, both Master and Padawan were captured and subjected to torture, allowing the dark side of the Force to transform Suduri into the Second Sister. Having forsaken her former identity and the Jedi way, the Second Sister was a relentless Inquisitor dedicated to destroying the last remnants of the Jedi Order. An ambitious and cruel woman, she sadistically toyed with her prey and desired to win the approval of Emperor Palpatine.

In 14 BBY, the Second Sister tracked the Jedi fugitive Cal Kestis to the planet Bracca. Kestis managed to escape from the Inquisitors with the help of Junda, however. As a result, the Second Sister hunted the two Jedi across the galaxy, confronting Kestis on Zeffo and later Bogano. When the Second Sister acquired a holocron containing the list of Force-sensitive younglings, Kestis followed her to the Inquisitorius headquarters on Nur and defeated the Second Sister in a lightsaber duel, giving Junda a chance to make amends with her fallen apprentice. Their reconciliation was cut short by the arrival of the Sith Lord Darth Vader, who executed the Second Sister for her failure. Before her death, the former Trilla Suduri told Kestis and Junda to avenge her as well as the other victims of the Jedi Purge.
</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://66.media.tumblr.com/ce2844bf343c9efdbf7ce77c80dad931/tumblr_pd1scwvxjy1wxjpwto1_640.jpg"></div>
		<div class="cont">
			<h3>Qi'ra</h3>
			<p style="font-size:65% ">  was a human female from the planet Corellia who lived during the reign of the Galactic Empire. She grew up on the streets along with Han as part of the White Worms. Though they were at first rivals, the two Scrumrats eventually fell in love and became lovers. Sometime after Qi'ra was made Head Girl by Lady Proxima, Han and Qi'ra attempted to escape with a vial of coaxium, but were separated at the Coronet Spaceport, Han got out but promised to return for her.

Qi'ra was sold into slavery by Proxima to the slave dealer Sarkin Enneb, who eventually sold her to Dryden Vos, the public leader of Crimson Dawn. Vos trained Qi'ra in martial arts and prompted her to kill Enneb, branding her right wrist with the Crimson Dawn symbol and making her his most trusted lieutenant.

In 10 BBY, Qi'ra reunited with Solo on Vandor and accompanied him and his friends on a mission to retrieve coaxium. She recommended a ship owned by the smuggler Lando Calrissian and rekindled her relationship with Solo. After the mission was unsuccessful, she returned to Vos, whom she betrayed and killed to save Han. Despite this, however, Qi'ra left Solo behind as she traveled to Dathomir to meet with Maul, the true leader of Crimson Dawn.</p>
		</div>
	</div>
	<div class="box">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/d/d1/Tobias_Beckett_Promo.jpg/revision/latest?cb=20180529071635"></div>
		<div class="cont">
			<h3>Tobias Beckett</h3>
			<p style="font-size: 95%">  was a human male professional thief and gunslinger who worked for the Crimson Dawn crime syndicate during the era of the Galactic Empire. A native of Glee Anselm, Beckett organized a crew to help with his heist missions. Although he became a mentor to Han Solo, a young mudtrooper who joined Beckett's group, Beckett was a survivor who quietly worked out angles that enabled him to come out ahead. He made use of many blasters, including the RSKF-44 heavy blaster and DG-29 heavy blaster pistol. He also owned a DL-44 heavy blaster pistol before he gave it to Solo.</p>
		</div>
	</div>

	<div class="box">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/9/95/Enfys_Nest_Databank.png/revision/latest/scale-to-width-down/350?cb=20180914200004"></div>
		<div class="cont">
			<h3>Enfys Nest</h3>
			<p style="font-size: 65%">was a human female resistance fighter who led the Cloud-Riders, a band of pirates and rebel group that fought against the crime syndicate Crimson Dawn. Nest's skills as a pirate earned her a reputation as an infamous marauder including in Crimson Dawn, who Nest and her Cloud-Riders actively fought against in retaliation for the atrocities Crimson Dawn had committed against them. Nest, who wore a battle helmet passed down to her from her mother, had run-ins with Crimson Dawn operative Tobias Beckett and his gang.

In 10 BBY, Nest and the Cloud-Riders sparred with Beckett and his crew, including Han Solo, as they competed for a score of valuable hyperspace fuel called coaxium. After both groups failed to steal a shipment on Vandor, Nest and her lieutenant, Weazel, tracked Beckett's crew as they stole coaxium from Kessel. Nest and the Cloud-Riders found Beckett's crew on Savareen, where she revealed the group's true purpose as allies fighting against Crimson Dawn. Solo sided with Nest and they teamed up to steal the coaxium from Crimson Dawn, dealing the syndicate a critical blow in the process. Nest intended to use the coaxium to help give life to a rebellion, so she gave the coaxium to Saw Gerrera of the Partisans and his young ward, Jyn Erso.</p>
		</div>
	</div><div class="box">
		<div class="imgBx"><img src="https://article-imgs.scribdassets.com/4o2tp4otz46fcwd8/images/fileL8WOD0TE.jpg"></div>
		<div class="cont">
			<h3>L3-37</h3>
			<p style="font-size:59% "> abbreviated L3, or Elthree, or Vuffi, was a feminine custom self-made piloting droid associated with Lando Calrissian who was active during the reign of the Galactic Empire. She was a one-of-a-kind droid, assembling and improving herself with scraps of other droids, including her torso, which she pieced together from an old astromech. Her brain module began as part of an R3-series astromech droid, including data from an espionage droid, custom coding and protocol droid processors.

L3 was also built from already used protocol parts and was also an enlightened navigator. She cared deeply about droid rights, a trait which led to her eventual demise.While L3-37 and Lando Calrissian were on Batuv, Calrissian was approached by the Petrusian Kristiss, who wanted to hire him to smuggle weaponry into the Imperial outpost on the world of Kullgroon. Knowing that the outpost held slaves, and that Calrissian had debts to pay to Brushaun, a gambler who had lost two thousand credits to him, L3 convinced him to accept the mission. As they left Batuv on the Millennium Falcon, they were attacked by Imperial TIE fighters. Calrissian told L3 to take the ship's controls while he shot back at the TIEs. As the ship's shields took severe damage, Calrissian ordered L3 to maneuver around a small moon so he could destroy the TIEs. Before Calrissian could show off, L3 told him that they were approaching Kullgroon.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://lumiere-a.akamaihd.net/v1/images/ziro_the_hutt_79826012.jpeg?region=572%2C0%2C1612%2C1608&width=960"></div>
		<div class="cont">
			<h3>Ziro Hutt</h3>
			<p style="font-size:65% ">

 Ziro formed a secret pact with Count Dooku—the leader of the Confederacy of Independent Systems—during the early days of the Clone Wars. With the help of the Separatists, Ziro had his great-nephew Rotta abducted and taken to a B'omarr monastery on the distant world of Teth. Knowing the Jedi Order would send their own to rescue the Huttlet, Ziro hoped that the deaths of Rotta's would-be Jedi saviors would lead to a conflict between Jabba and the Republic. With Jabba removed from power, Ziro would be in a position to seize control of their clan.

Ziro's role in the conspiracy was discovered by Senator Padmé Amidala, who confronted the gangster in his nightclub on Coruscant during the mission to rescue Rotta. With Rotta safely returned to his father on Tatooine, Ziro was taken into custody by the Coruscant Guard. However, as the war progressed, the Grand Hutt Council regarded Ziro as too dangerous to be left in a Republic prison, given his knowledge of their inner workings. As a result, the Hutts recruited the bounty hunter Cad Bane, who freed Ziro and turned him over to the Hutt Council. Although Ziro escaped the Hutts as well, he was ultimately murdered by the alien singer Sy Snootles, Ziro's one-time lover whom Jabba hired to kill his uncle and retrieve the Hutt Council records</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://us.v-cdn.net/6025736/uploads/editor/tk/lsg4c2zhj6qb.png"></div>
		<div class="cont">
			<h3>Pre Vizsla</h3>
			<p style="font-size:61% ">was a human male Mandalorian warrior who led a terrorist organization, known as Death Watch, during the final years of the Galactic Republic. Formerly the governor of Concordia, Vizsla longed to restore the warrior heritage of his homeworld, the planet Mandalore, by overthrowing Duchess Satine Kryze's pacifist regime. Drawing on the support of his Mandalorian commandos, Vizsla made his bid for power during the galaxy-wide Clone Wars but failed several times in his efforts to conquer Mandalore. Following his failed alliance with the Confederacy of Independent Systems, however, Vizsla joined the former Sith Lord Darth Maul's Shadow Collective. As a result of their pact, he ultimately succeeded in taking over Mandalore with widespread public support following the collapse of order and stability due to Maul's machinations.

Having achieved his goal, Vizsla turned against Maul, leading to a lightsaber duel to the death. In the end, Vizsla was defeated and executed by Maul, who claimed his one-time ally's weapon—the Darksaber, a Jedi-Mandalorian relic of Clan Vizsla—and therefore leadership over all Mandalorians. Despite Maul's victory, his claim was opposed by one of the late Vizsla's lieutenants, Bo-Katan Kryze, who refused to accept an outsider as her leader. This act tore Death Watch asunder between Kryze's supporters and those who declared their loyalty to Maul, becoming known as his Mandalorian super commandos.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://i.pinimg.com/originals/8a/5e/a2/8a5ea202271968795572275d72e2de74.jpg"></div>
		<div class="cont">
			<h3>Gial Ackbar</h3>
			<p style="font-size: 59% ">was a veteran male Mon Calamari soldier and strong revolutionary leader during the Clone Wars, the Galactic Civil War, the cold war, and the war between the Resistance and the First Order. Throughout his sixty years of service, Ackbar was regarded as a brilliant tactician.

Ackbar was captain of the Mon Calamari Guard during the Clone Wars and fought in the Battle of Mon Cala, in which he helped to secure Prince Lee-Char's ascent as King of Mon Cala and repel the Confederacy of Independent Systems. After the rise of the Galactic Empire, Ackbar became the foremost military commander in the Alliance to Restore the Republic, emerging as a symbol of defiance against the Empire's subjugation of non-humans. His presence attracted Mon Calamari support for the Alliance, thus supplying the Mon Calamari star cruisers that made up a bulk of the Alliance Fleet.

By 34 ABY, the emerging threat of the First Order, which arose from the ashes of the Empire, led Princess Leia Organa to form the Resistance without the support of the Republic that had turned a blind eye to the First Order. Organa, the general of the Resistance, coaxed Ackbar out of his retirement to serve in the Resistance. After reclaiming his commission as an Admiral, Ackbar served in the Resistance base on D'Qar, where he helped oversee the battle to destroy the First Order superweapon known as Starkiller Base.

Ackbar was later present on the bridge of the Resistance's flagship the Raddus when the Resistance evacuated from D'Qar, but was blown up and killed when the First Order attacked the ship after it exited hyperspace. </p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/b/b2/Padmegreenscrshot.jpg/revision/latest/scale-to-width-down/500?cb=20100423143631"></div>
		<div class="cont">
			<h3>Padme Amidala</h3>
			<p style="font-size:57% ">also known as Padmé Amidala Naberrie, was a human female senator who represented the people of Naboo during the final years of the Galactic Republic. Prior to her career in the Galactic Senate, Amidala was the elected ruler of the Royal House of Naboo. A political idealist, she advocated for the preservation of democracy as well as a peaceful resolution to the Clone Wars. After surviving an assassination attempt, she was removed from the capital and sent back to Naboo under the protection of Padawan Anakin Skywalker. Though the Jedi Code forbade personal relationships, deeming attachment and possession unbecoming of a Jedi, the two gradually became closer as their feelings for each other grew. In the aftermath of the Battle of Geonosis, Amidala secretly married her Jedi protector, despite her own reservations about their relationship and the consequences they would face if the truth ever came to light. Their subsequent interactions were limited throughout the Clone Wars, with Amidala continuing to advocate peaceful solutions in the Senate while Skywalker served on the front lines as a Jedi General in the Grand Army of the Republic. In the waning months of the pan-galactic conflict, Amidala revealed to her husband that she was pregnant. As a result of Skywalker's fear of loss, he was seduced by the dark side of the Force, believing that by becoming a Sith Lord he would gain the power to prevent his wife from dying in childbirth. Amidala, who learned of her husband's transformation into a Sith, ultimately died of a broken heart after giving birth to the twins Luke Skywalker and Leia Amidala Skywalker. With her dying breath, she claimed that there was still good in the former Anakin Skywalker, who embraced the persona of Darth Vader throughout the reign of the Galactic Empire.
</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/3/3e/FACadBane.png/revision/latest?cb=20170909123958"></div>
		<div class="cont">
			<h3>Cad Bane</h3>
			<p style="font-size:65% ">was a Duros male bounty hunter in the galaxy during the Clone Wars. He was considered the leading bounty hunter in the galaxy due to the death of Jango Fett at the Battle of Geonosis. He specialized in fighting Jedi.At some point prior to the Battle of Naboo, Cad Bane met the Sith Lord Darth Maul on Nar Shaddaa. He, along with fellow bounty hunters Aurra Sing, Troo-tril-tek and Vorhdeilo assisted Maul in acquiring Jedi Padawan Eldra Kaitis from Xev Xrexus's auction. During the auction, Bane and Vorhdeilo killed several of Jee Kra's crew aboard his Shekelesh-class freight gunship. Bane, along with Maul, Sing and Vorhdeilo then met up with Kra and Kaitis at Kra's gunship. Bane piloted Kra's ship after Maul subdued Kra's men. Bane and Sing then discussed killing Maul.
However, their ship was sabotaged, and they were forced to crash-land on the Moon of Drazkel. Bane along with Maul, Kaitis, Sing and Vorhdeilo survived the crash. Bane then saw that Xrexus was making a sport and profit out of them. As Maul took Kaitis with him, Bane, Sing and Vorhdeilo prepared to fight Xrexus' clients. Bane fought several Trandoshans alongside Vorhdeilo and Sing. Bane, Sing, and Vorhdeilo then stole a ship from the Ohnaka Gang after he took the last of the Trandoshans. Bane and the others picked up Maul and left him to take out Xrexus at her hideout. 
</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://lumiere-a.akamaihd.net/v1/images/Jabba-The-Hutt_b5a08a70.jpeg?region=0%2C0%2C1200%2C675&width=768"></div>
		<div class="cont">
			<h3>Jabba Hutt</h3>
			<p style="font-size: 57%">  was a major figure on Tatooine, where he controlled the bulk of the trafficking in illegal goods, piracy and slavery that generated most of the planet's wealth. He was also highly influential in the entire Outer Rim as one of its most powerful crime lords.

During the Clone Wars, Jabba's influence and power over the Outer Rim, specifically its hyperlanes, was sought by both the Galactic Republic and the Confederacy of Independent Systems, who both courted Jabba's approval. When Rotta, Jabba's son, was kidnapped, the crime lord promised his support to whomever returned his son. When the Separatists were revealed to have orchestrated Rotta's kidnapping, Jabba pledged his support to the Republic.

Jabba continued to operate in the Outer Rim after the end of the Clone Wars and the rise of the Galactic Empire, preserving his power base, despite the interference of Darth Sidious, the Galactic Emperor. After the destruction of the Death Star by the Rebel Alliance, the Emperor sent Darth Vader to negotiate a deal with Jabba to secure raw materials for Imperial military production. Jabba's alliance with the Empire allowed him and the Hutts to survive the Imperial crackdown against criminal elements in the Outer Rim, as well as rid the Hutt of his competitors.

After the smuggler Han Solo failed to repay him for lost cargo, Jabba placed a high price on his head. Solo was eventually delivered to him by one of his bounty hunters, Boba Fett, as a gift from Darth Vader. However, this capture brought him to the attention of Jedi Knight Luke Skywalker, who sought to rescue his friend from Jabba's imprisonment. As he attempted to execute the Jedi and his allies in the Great Pit of Carkoon, Jabba was choked to death by Leia Organa.</p>
		</div>
	</div>

	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/5/50/Bailrogueone.jpeg/revision/latest?cb=20170924232338"></div>
		<div class="cont">
			<h3>Bail Organa</h3>
			<p style="font-size:85% ">was a Human male who served as the First Chairman and Viceroy of Alderaan, and served in the Galactic Senate as the Senator of the Alderaan sector. Subsequently, he was Senator of the Alderaan sector of the Imperial Senate He was Princess Leia Organa's adoptive father and a friend of Jedi Masters Obi-Wan Kenobi, Yoda, Rahm Kota, and Jedi Knight Ylenic It'kla. He was also a friend and colleague of Leia's biological mother, Senator Padmé Amidala, and was present when Leia and Luke were born. He was married to Queen Breha Organa. One of the main founders of the Rebel Alliance, he was killed when the Death Star obliterated Alderaan. In the Alliance and its successor states, the New Republic and Galactic Federation of Free Alliances, he was respected as a martyr who died for his cause.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/8/87/DarthBaneAncientMaster-CM.png/revision/latest/scale-to-width-down/350?cb=20200113215857"></div>
		<div class="cont">
			<h3>Darth Bane</h3>
			<p style="font-size:70% "> was a legendary human male Dark Lord of the Sith and the sole survivor of the destruction of the Sith at the hands of the Jedi Order during the Jedi-Sith War a thousand years before the Clone Wars. As the only surviving Sith, Bane recognized that Sith infighting had weakened them to the point that the Jedi could destroy them. To rectify this, Bane reformed the Sith and created the Rule of Two, mandating that there could be only two Sith—a Master and an apprentice—at any given time. These new Sith would begin a plot to destroy the Jedi in secret. With Bane's defeat, the Jedi wrongly believed that the Sith were defeated with him.

The vendetta Bane held against the Jedi was fulfilled during the Clone Wars, when Supreme Chancellor Sheev Palpatine, secretly the Sith Lord Darth Sidious and a follower of the Rule of Two, transformed the Galactic Republic into the Galactic Empire and destroyed the Jedi Order. However, the victory was short-lived, as the redeemed Jedi Knight Anakin Skywalker, formerly the Sith Lord Darth Vader, defeated the Sith twenty-three years later.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://i.ytimg.com/vi/4KPd_xlzc6U/maxresdefault.jpg"></div>
		<div class="cont">
			<h3>Bossk</h3>
			<p style="font-size:78% ">
was a male Trandoshan bounty hunter and the son of Cradossk who was known for hunting Wookiees. During the Clone Wars, Bossk worked alongside fellow hunters Aurra Sing and Castas to mentor the orphaned Boba Fett. Their scheme to kill Fett's hated enemy Mace Windu resulted in Fett and Bossk's arrest. After a stint in prison, Bossk worked in Krayt's Claw, Fett's syndicate of bounty hunters, taking jobs for clients including Otua Blank and Asajj Ventress.

After the rise of the Empire, Bossk traveled to the Outer Rim planet of Lothal to collect a bounty on the Dug criminal Gronson Takkaro, who had jumped bail in the Ahakista system. During his trip Bossk also joined forces with the Force-sensitive street urchin Ezra Bridger to stop the corrupt Imperial Security Bureau Lieutenant Jenkes. Following the Battle of Hoth, Bossk would be called upon by Darth Vader to find and capture the Millennium Falcon.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://img5.goodfon.ru/wallpaper/nbig/2/7e/tony-foti-by-tony-foti-star-wars-force-destiny-luminara-undu.jpg"></div>
		<div class="cont">
			<h3>Luminara Unduli</h3>
			<p style="font-size:75% ">was a Force-sensitive Mirialan female Jedi Master during the final days of the Jedi Order. She commanded the 41st Elite Corps of the Grand Army of the Republic, and was the master of Padawan Barriss Offee. Together, they fought in numerous battlefields of the Clone Wars, before Offee turned against the Jedi Order and bombed the Jedi Temple.

At the end of the war, Unduli fought in the battle on Kashyyyk. She was arrested and executed after Supreme Chancellor Sheev Palpatine issued Order 66 and destroyed the Jedi Order. The Galactic Empire would later use her remains to attract and kill any Jedi that survived Order 66. One such trap was laid for Kanan Jarrus and the crew of the Ghost, who believed Unduli was alive and being imprisoned on Stygeon Prime. They mounted a rescue mission, only to discover that it was a trap by the Grand Inquisitor. The rebels escaped with the knowledge that Unduli was dead and spread the word to dispell the ruse, preventing any more deaths in her name.</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/7/79/Savage_Opress_missing_horn.png/revision/latest/scale-to-width-down/350?cb=20160131004655"></div>
		<div class="cont">
			<h3>Savage Opress</h3>
			<p style="font-size:57% ">was a Dathomirian Nightbrother who became a Sith apprentice under Darth Tyranus and later became a Sith Lord, apprenticed to his brother Darth Maul during the Clone Wars.

Originally a tribal leader on Dathomir, Opress was handpicked by the Nightsister Asajj Ventress to become her 'mate' and servant following her grueling tests of Selection, as part of her bid for revenge on her former Master, the Sith Lord Count Dooku. In accordance with their plot against Dooku, Mother Talzin and her Nightsister witches employed their dark magic to grant Opress fearsome abilities, placing him under their control. After murdering his beloved brother Feral in a display of loyalty to Ventress, Opress entered the Clone Wars as a dark acolyte, serving as an enforcer in Dooku's Confederacy of Independent Systems.

However, Opress would soon see he was being used by Ventress and betrayed both her and Dooku and fled, being guided on a quest by Mother Talzin to seek out his lost brother. Opress was led to the junkyard world of Lotho Minor, where he found his brother Maul half-mad. He brought his brother back to Talzin, who restored both his mid, and his legs. She then left the pair together as Maul became reconnected with the changed world around him. He and Savage then embarked on a quest of death and chaos, seeking vengeance on Jedi Master Obi-Wan Kenobi.

Seeking to take everything he loved from him, Maul conquered Mandalore and killed his lover, Satine Kryze. Opress stood by his brother as he enacted his revenge, but they would soon be faced by the arrival of Maul's old master, Darth Sidious. Sidious would fight Maul and Savage, but would ultimately kill Savage Opress in battle, leaving Maul to mourn his brother's death.
</p>
		</div>
	</div>
	<div class="boxx">
		<div class="imgBx"><img src="https://vignette.wikia.nocookie.net/starwars/images/a/ad/ShmiSkywalkerDatabank_%28Repurposed%29.jpeg/revision/latest/scale-to-width-down/499?cb=20171114023541"></div>
		<div class="cont">
			<h3>Shmi Skywalker</h3>
			<p style="font-size:57% ">  was a human female who lived in slavery on the planet Tatooine during the last years of the Galactic Republic. During her time as a slave, she gave birth to a child called Anakin Skywalker. her son was discovered by Jedi Master Qui-Gon Jinn, who found the boy to be unusually strong with the Force. He learned through Shmi that there was no father involved in Anakin's conception, leading Jinn to believe that Anakin was conceived by the midi-chlorians. With Shmi's support, Anakin was taken by Jinn to the Jedi Temple on Coruscant and presented to the leaders of the Jedi Order as the Chosen One—the one who was destined to restore balance to the Force, according to Jedi prophecy.

After Anakin left Tatooine to begin his Jedi training, Shmi married Cliegg Lars—a moisture farmer who freed her from slavery—and became a loving stepmother to his son, Owen Lars. Her chance to see Anakin one last time came when, in the waning days of the Separatist Crisis, Shmi was abducted and subjected to torture by a group of Tusken Raiders. By then, her son had returned to Tatooine as a Jedi Padawan. Having seen her son again, Shmi told him she was complete but died in his arms. Unable to prevent his mother's demise, Anakin gave into the dark side of the Force and massacred the Tusken Raiders, including their women and children, and buried his mother at the Lars moisture farm. Shortly after Shmi's death, her son went on to become a Jedi Knight, as well as a general in the Grand Army of the Republic during the galaxy-wide conflict known as the Clone Wars. The loss of his mother also pushed him to desire the ability to save his loved ones from death, which ultimately pushed Skywalker to become Darth Sidious's Sith apprentice.</p>
		</div>
	</div>
</div>
    

<script type="text/javascript">
  function togglePopup(){
  document.getElementById("popup-1").classList.toggle("active");
}
</script>
</body>
</html>