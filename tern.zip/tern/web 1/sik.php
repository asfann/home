!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<form method="post">
    <input type="text" name="x"><br>
    <input type="text" name="y"><br>
    <button type="submit" name="submit"
    >submit</button>
</form>
</body>
</html>


<?php

//2
$array = array(1, 3, 5, 7, 9);
for ($i = 0; $i < sizeof($array) - 1; $i++) {
    echo  $array[$i] + $array[$i + 1], "<br>";
?>


<?php
   //3
    $in = 3;
    $ar = [1, 2, 3];

    for($i = 0; $i < count($ar); $i++) {
    echo $ar[$i] * $in." ";
    }
 ?>
<?php //4
$x=$_POST['x'];
    $y=$_POST['y'];
    echo $x+$y,"<br>";

}
?>