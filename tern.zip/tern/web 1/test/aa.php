<?php
$array = ["Zero" => 1, "First" => 2, "Second" => "third"];
foreach ($array as $key) {
    echo $key . " ";
}
echo '<br>';
foreach ($array as $item => $value) {
    echo $item . " " . $value, " ";
}

echo "<br>";
$first = ["Name" => "Sultan", "Age" => 18, "Course" => "IT"];
$second = ["Name" => "Muratzhan", "Age" => 17, "Course" => "TS"];
$third = ["Name" => "Zufar", "Age" => 19, "Course" => "CS"];
$fourth = ["Name" => "Magzhan", "Age" => 17, "Course" => "ITM"];
$fifth = ["Name" => "Asfandiyar", "Age" => 19, "Course" => "IT"];

$info = [$first, $second, $third, $fourth, $fifth];
foreach ($info as $kek) {
    foreach ($kek as $ek) {
        echo $ek;
        echo " ";
    }
    echo "<br>";
}
foreach ($info as $lol) {
    foreach ($lol as $ol => $ley) {
        echo $ol . " " . $ley . " ";
    }
    echo "<br>";
}
$any = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
foreach ($any as $yna) {
    echo $yna * 10;
    echo " ";
}
echo "<br>";
$anyy = [11, 22, 33, 44, 55, 66, 77, 88, 99, 100];
$multany = [$any, $anyy];
foreach ($multany as $ult) {
    foreach ($ult as $lut) {
        echo $lut * 10;
        echo " ";
    }
    echo "<br>";
}

?>