<?php
    session_start();

    if (isset($_SESSION['user'])) {
        header("Location: user_profile.php");
        return;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>JSON Example</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"
            integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
            crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $("#submitbtn").click(function(){
                event.preventDefault();
                $.ajax('authorization.php', {
                    type: 'POST',  // http method
                    data: { email: $( "#exampleInputEmail1" ).val(),
                        password:  $( "#exampleInputPassword1" ).val()},  // data to submit
                    accepts: 'application/json; charset=utf-8',
                    success: function (data) {
                        if (data.message == 'success') {
                            window.location.href = "user_profile.php";
                        }
                    },
                    error: function (errorData, textStatus, errorMessage) {
                        var msg = (errorData.responseJSON != null) ? errorData.responseJSON.errorMessage : '';
                        $("#errormsg").text('Error: ' + msg + ', ' + errorData.status);

                        $("#errormsg").show();
                    }
                });
            });

            //BORDERS FOR FORMS
            $('#exampleInputEmail1').focus(function () {
               $('.focussing').addClass('border border-primary');
                $('.focussing2').removeClass('border border-success');
                $('#submitbtn').prop('disabled', false);
                $('#regbtn').prop('disabled', true);
            });
            $('#exampleInputPassword1').focus(function () {
                $('.focussing').addClass('border border-primary');
                $('.focussing2').removeClass('border border-success');
                $('#submitbtn').prop('disabled', false);
                $('#regbtn').prop('disabled', true);
            });

            $('#regEmail').focus(function () {
                $('.focussing2').addClass('border border-success');
                $('.focussing').removeClass('border border-primary');
                $('#submitbtn').prop('disabled', true);
                $('#regbtn').prop('disabled', false);
            });
            $('#regName').focus(function () {
                $('.focussing2').addClass('border border-success');
                $('.focussing').removeClass('border border-primary');
                $('#submitbtn').prop('disabled', true);
                $('#regbtn').prop('disabled', false);
            });
            $('#regSurname').focus(function () {
                $('.focussing2').addClass('border border-success');
                $('.focussing').removeClass('border border-primary');
                $('#submitbtn').prop('disabled', true);
                $('#regbtn').prop('disabled', false);
            });
            $('#regPass').focus(function () {
                $('.focussing2').addClass('border border-success');
                $('.focussing').removeClass('border border-primary');
                $('#submitbtn').prop('disabled', true);
                $('#regbtn').prop('disabled', false);
            });
            $('#regAva').focus(function () {
                $('.focussing2').addClass('border border-success');
                $('.focussing').removeClass('border border-primary');
                $('#submitbtn').prop('disabled', true);
                $('#regbtn').prop('disabled', false);
            });
            $('#regDate').focus(function () {
                $('.focussing2').addClass('border border-success');
                $('.focussing').removeClass('border border-primary');
                $('#submitbtn').prop('disabled', true);
                $('#regbtn').prop('disabled', false);
            });
            //BORDERS FOR FORMS

            //CHECK MAIL
            $('#regEmail').change(function () {
                var mail = $('#regEmail').val();

                $.ajax({
                    type: "POST",
                    url: "checkmail.php",
                    data: {"mail": mail},
                    success: function (msg) {
                        if(msg == 'reserved'){
                            $('#checkMail').text("Account is reserved");
                            $('#checkMail').show();
                        }
                        else if(msg == 'free'){
                            $('#checkMail').text("Mail is free");
                            $('#checkMail').removeClass(' text-danger');
                            $('#checkMail').addClass(' text-success');
                            $('#checkMail').show();
                        }
                    }
                });
            });
            //CHECK MAIL

            //REGISTER ACCOUNT
            $('#regbtn').click(function (event) {
                event.preventDefault();
                $.ajax({
                    type: "POST",
                    url: "register.php",
                    data: {
                        "mail": $('#regEmail').val(),
                        "name": $('#regName').val(),
                        "surname": $('#regSurname').val(),
                        "pass": $('#regPass').val(),
                        "urlAva": $('#regAva').val(),
                        "birthday": $('#regDate').val()
                    },
                    success: function (response) {
                        if(response == 'success'){
                            alert("Account was successfully registered!");
                            window.location.href = "signin.php";
                        }
                        else if(response == 'failed'){
                            alert("Fields must not be empty!");
                        }
                        else if(response == 'failed reg'){
                            alert("Registration error");
                        }
                    }
                });
            });
        });
    </script>
</head>

<body>
<?php include_once('header_with_theme.php'); ?>
<div class="container container-login">
    <div class="row">
        <div class="col-md-4">
            <form class="focussing">
                <span class="error text-danger" id="errormsg" style="display: none"></span>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>
                <button type="submit" class="btn btn-primary" id="submitbtn">Submit</button>
            </form>
        </div>

        <div class="col-md-4">
            <form class="focussing2">
                <span class="error text-danger" id="checkMail" style="display: none"></span>
                <div class="form-group">
                    <label for="regEmail">Email</label>
                    <input type="email" class="form-control" id="regEmail" placeholder="Enter email">
                </div>

                <div class="form-group">
                    <label for="regName">First Name</label>
                    <input type="text" class="form-control" id="regName" placeholder="Enter first name">
                </div>

                <div class="form-group">
                    <label for="regSurname">Second Name</label>
                    <input type="text" class="form-control" id="regSurname" placeholder="Enter second name">
                </div>

                <div class="form-group">
                    <label for="regPass">Password</label>
                    <input type="password" class="form-control" id="regPass">
                </div>

                <div class="form-group">
                    <label for="regAva">URL Avatar</label>
                    <input type="url" class="form-control" id="regAva" placeholder="Enter avatar URL">
                </div>

                <div class="form-group">
                    <label for="regDate">Birthdate</label>
                    <input type="date" class="form-control" id="regDate" placeholder="Enter birth date">
                </div>

                <button type="submit" class="btn btn-success" id="regbtn">Registrate</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>