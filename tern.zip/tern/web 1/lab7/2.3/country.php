<?php
if($_REQUEST["country"]) {
    echo "What is the capital of " .$_REQUEST['country'];
}
?>