<?php

$JJBA = array (
    array("Phantom Blood" => "Jonathan Joestar"),
    array("Battle Tendency" => "Joseph Joestar"),
    array("Stardust Crusaders" => "Jotaro Kujo"),
);

    echo json_encode($JJBA);

?>
