<?php

/*$array = [];
for ($i = 0; $i < 10;$i++) {
    if ($i < 4) {
        $array[$i] = 'a';
    } else if ($i > 4 || $i < 7) {
        $array[$i] = 'b';
    } else($i >= 8){
    $array[$i] = 'c';
    }
}

foreach ($array as $asss) {
    echo $asss;
    echo "<br>";
}

$string = "Marat Asfandiyar";
for ($i = 0; $i < strlen($string); $i++) {
    echo $string [$i];
    echo "<br>";
}
echo strlen($string);
echo "<br>";
$C=100;
for ($i = 0;$i<$C;$i++){
    if($i % 10 ==0){
        echo $i;
        echo "<br>";
    }
}

$f = ["City" => "Nur-sultan","uni" => "Astana IT University","country"=>"Kazakhstan"];
$s =  ["City" => "Almaty", "uni" => "KBTU","country"=>"Kazakhstan"];
$t =  ["City" => "Almaty", "uni" =>"SDU","country"=>"Kazakhstan"];
$fo =  ["City" => "Almaty", "uni" => "KIMEP","country"=>"Kazakhstan"];
$fi =  ["City" => "Boston","uni" => "MSU","country"=>"Russia"];
$si =["City" => "Boston","uni" => "Harvard","country"=>"USA"];
$se =["City" => "California","uni" => "Stanford","country"=>"USA"];
$e = ["City" => "Oxford","uni" => "Oxford","country"=>"UK"];

$table = [$f,$s,$t,$fo,$fi,$si,$se,$e];
foreach ($table as $key)  {
        if (array_key_exists("uni", $key)) {
            echo $key["uni"], ":", $key["City"], ",", $key["country"];
            echo "<br>";
        }
}
sort($table,0);

foreach ($table as $key) {

    if (array_key_exists("uni", $key)) {
        echo $key["uni"], ":", $key["City"];
        echo "<br>";
    }
}*/
$usern=$_POST['user'];
$passwo=$_POST['password'];

$usernn =['asfa'=>228];
$usernnn =['afsa'=>322];
$mult = [$usernn,$usernnn];
    foreach ($mult as $item) {
        foreach ($item as $key => $value) {
        }

        if (isset($_POST['submit'])) {
            if (!empty($usern) && !empty($passwo)) {
                if ($usern == $key && $passwo == $value) {
                    echo "access granted";
                }} else {
                    echo "denied";
                }
            }


        }
    

