<?php
/*$arrat= [1,2,3,4,5,6];
foreach ($arrat as $value){
    echo $value;
    echo "<br>";

}*/

for($i=0; $i<10;i++){
    echo "This is ".$i."th iteration";
    echo"<br>";
}
?>