<?php

session_start();

$con = mysqli_connect('localhost','asfa','uXLB5ClvBvnaFdig');

mysqli_select_db($con, 'endterm');

$name=$_POST['user'];
$pass=$_POST['Password'];

$s = "SELECT * FROM usertable WHERE name = '$name' && password ='$pass'";

$res=mysqli_query($con,$s);

$num=mysqli_num_rows($res);

if ($num==1) {
	$_SESSION['username'] = $name;
	header('location:mmain.php');
}else{
	header('location:login.php');
	}
?>