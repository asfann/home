<?php
require 'include/indexx.php';
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $sql = "INSERT INTO kujo"
}