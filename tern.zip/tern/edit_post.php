<?php
   include('session.php');
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Post</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <style media="screen">
    .textdiv {
      margin: 100px;
      opacity: 1;
      color: black;
      border: white solid 3px;
      border-radius: 5px;
      display: flex;
      text-align: center;
      flex-direction: column;
      justify-content: space-around;
      height: 500px;
      padding: 10px;
      height: 70%;
    }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-dark navbar-dark fixed-top">
      <!-- Brand -->
      <a class="navbar-brand" href="mainpage.html"><img src="Logo..png" alt="" height="50px" ></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <li class="nav-item">
              <a class="nav-link" href="firstpage.php">All blogs</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="yourblogs.php">Here's your blogs</a>
            </li>

          <li class="nav-item dropdown" style="position: absolute; right: 15px;">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo $login_session; ?>
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="logout.php">Log out</a>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <?php
    $sql_name = "SELECT * FROM post";
    $res = mysqli_query($db, $sql_name);
    if($res == false){
      echo mysql_error($db);
    }
    $cout = mysqli_fetch_all($res, MYSQLI_ASSOC);
     ?>

    <?php
    $value = $_POST['id'];
    $value;
    $coutt = $cout[$value-1]["post_name"];
           $text = $cout[$value-1]["post_content"];
     ?>
     <div class="textdiv">

     <form class=""  method="post">
       <div class="">
         <label for="name">Post name</label>
         <input type="text" name="name2" value="<?php echo $coutt; ?>">
       </div>
       <div class="">
         <label for="Text">Post content</label>
         <textarea name="Text" rows="8" cols="80"><?php echo $text; ?></textarea>
         <input type="hidden" name="id" value="<?php echo $value; ?>">
       </div>
       <input type="submit" name="" value="Edit post">
     </form>
     <?php
     if($_SERVER["REQUEST_METHOD"] == "POST") {
       if(isset($_POST["name2"])){
         $sql = "UPDATE post SET post_name = '".$_POST['name2']."' Where post_id = '".$_POST['id']."'";
         $resultat = mysqli_query($db, $sql);
         if($resultat == false){
           echo mysqli_error($db);
         }else{
           header("location:firstpage.php");
         }
       }
       if(isset($_POST["Text"])){
         $sql = "UPDATE post SET post_content = '".$_POST['Text']."' Where post_id = '".$_POST['id']."'";
         $resultat = mysqli_query($db, $sql);
         if($resultat == false){
           echo mysqli_error($db);
         }else{
             header("location:firstpage.php");
         }
       }
     }
      ?>
      <form class="" action="firstpage.php" method="post">
        <input type="submit" name="" value="Back to index page">
      </form>
     </div>
  </body>
</html>
