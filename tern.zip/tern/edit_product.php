<?php
require 'refjojo.php';
$sql="SELECT * FROM kujo";
$res=mysqli_query($conn,$sql);
if($res==false){
    echo mysqli_error($conn);
}else{
    $kujo = mysqli_fetch_all($res,MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<header>
    <h1>Products</h1>
</header>
</body>
</html>

