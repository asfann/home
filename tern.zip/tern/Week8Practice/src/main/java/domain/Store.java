package domain;

import java.util.Vector;

public class Store {
    Vector<Shoe> shoes;


}

