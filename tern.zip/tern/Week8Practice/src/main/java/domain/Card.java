package domain;

public class Card {
    private String cardNumber;
    private String fname;
    private String lname;
    private int cvv;
    private String validDate;

    public Card(String cardNumber, String fname, String lname, int cvv, String validDate) {
        this.cardNumber = cardNumber;
        this.fname = fname;
        this.lname = lname;
        this.cvv = cvv;
        this.validDate = validDate;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public int getCvv() {
        return cvv;
    }

    public void setCvv(int cvv) {
        this.cvv = cvv;
    }

    public String getValidDate() {
        return validDate;
    }

    public void setValidDate(String validDate) {
        this.validDate = validDate;
    }


}
