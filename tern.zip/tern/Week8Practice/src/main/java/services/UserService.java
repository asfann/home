package services;

import domain.User;
import services.interfaces.IUserService;

public class UserService implements IUserService {

    @Override
    public User getUserById(long id) {
        return null;
    }
}
