package services;

public class StoreService {
}
