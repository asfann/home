package services.interfaces;

import domain.Card;
import domain.ShoppingBasket;

public interface IPayService {
    public Card pay(ShoppingBasket shoppingBasket);
}
