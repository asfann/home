package services.interfaces;

import domain.Store;

public interface IStoreService {
    public Store getStore();
}
