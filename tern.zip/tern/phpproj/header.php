<?php 
    session_start();
?>
<!DOCTYPE html>
<html>

<head>
  <title>new</title>
  <link rel="stylesheet" type="text/css" href="css/styles.css">
  <script src="js/script.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>

<body>
    <nav>
      <div class="logo">
        <ul>
          <li><a href="index.php">home</a></li>
          <?php if (isset($_SESSION['userUid'])):?>
          <li style="padding-top: 12px;">
            <form action="includes/logout.inc.php" method="post">
              <input type="submit" class="btn" name="logout-submit" value="logout">
            </form>
          </li>
          <?php endif; ?>
        </ul>
      </div>
    <ul>
      <li><a href="#section-1" class = "current">main</a></li>
      <li><a href="#section-2">affiche</a></li>
      <li><a href="#section-3">video</a></li>
      <li><a href="#section-4">bio</a></li>
      <li><a href="#section-5">store</a></li>
      <?php if (isset($_SESSION['userUid'])):?>
        <li><a href="#section-6">comment</a></li>
      <?php endif; ?>
      <?php if (!isset($_SESSION['userUid'])):?>
      <li><a class="spln" href="login.php">login</a></li>      
      <li><a class="spln" href="signup.php">signup</a></li>
      <?php endif; ?>
    </ul>
    <script type="text/javascript">
      var mainNavLinks = document.querySelectorAll("nav ul li a");
      var mainSections = document.querySelectorAll("main section");
      window.addEventListener("scroll", event => {
        var fromTop = window.scrollY;
        mainNavLinks.forEach(link => {
          var section = document.querySelector(link.hash);
          if (
            section.offsetTop <= fromTop &&
            section.offsetTop + section.offsetHeight > fromTop
          ) {
            link.classList.add("current");
          } else {
            link.classList.remove("current");
          }
        });
      });
    </script>
  </nav>