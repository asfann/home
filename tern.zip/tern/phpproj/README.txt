Before using sites such as movies series and games,
you should wait a bit to get everything loaded.