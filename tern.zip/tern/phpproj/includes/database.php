<?php

	$db_host = 'localhost';
	$db_name = 'loginsystem';
	$db_user = 'Magzhan';
	$db_pass = 'mxhJrzQtTGtZcSoE';
    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    if (!$conn) {
        die ("ERROR: ".mysqli_connect_error());
    } 
?>