<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" type="text/css" href="css/lgstyle.css">
</head>

<body>
    <nav>
      <div class="logo">
        <ul>
          <li><a href="index.php">home</a></li>
        </ul>
      </div>
    </nav>
    <main>
        <form action="includes/signup.inc.php" method="post">
            <div class="login-box">
                <?php 
                    if (isset($_GET['error'])) {
                        if ($_GET['error'] == "emptyfields") {
                            echo '<p class="signuperror"> FILL IN ALL FIELDS!</p>';
                        }
                        if ($_GET['error'] == "invalidmailuid") {
                            echo '<p class="signuperror"> FILL VALID MAIL AND USERNAME!</p>';
                        }
                        if ($_GET['error'] == "invalidmail") {
                            echo '<p class="signuperror"> FILL VALID MAIL!</p>';
                        }
                        if ($_GET['error'] == "invaliduid") {
                            echo '<p class="signuperror"> FILL VALID USERNAME!</p>';
                        }
                        if ($_GET['error'] == "passwordcheck") {
                            echo '<p class="signuperror"> PASSWORDS NOT EQUAL!</p>';
                        }
                        if ($_GET['error'] == "sqlerror") {
                            echo '<p class="signuperror"> ERROR 500</p>';
                        }
                    } elseif (isset($_GET['signup']) && $_GET['signup'] == "success") {
                        echo '<p class="signupok"> SUCCESSFUL SINGUP</p>';
                    } 
                 ?>
              <h1>Sign up</h1>
              <div class="textbox">
                <i class="fas fa-user"></i>
                <input type="text" name="uid" id="uid" placeholder="Username">
              </div>

              <div class="textbox">
                <i class="fas fa-mail-bulk"></i>
                <input type="text" name="mail" placeholder="E-mail">
              </div>

              <div class="textbox">
                <i class="fas fa-lock"></i>
                <input type="password" name="pwd" placeholder="Password">
              </div>

              <div class="textbox">
                <i class="fas fa-lock"></i>
                <input type="password" name="pwd-repeat" placeholder="Repeat password">
              </div>

              <input type="submit" class="btn" name="signup-submit" value="Sign up">
            </div>
        </form>
    </main>

<?php 
    require "footer.php";
?>