<?php 
    require "header.php";
?>

    <main>
        <div class="container">
            <h1>Signup</h1>
                <?php 
                    if (isset($_GET['error'])) {
                        if ($_GET['error'] == "emptyfileds") {
                            echo '<p class="signuperror"> FILL IN ALL FIELDS!</p>';
                        }
                        if ($_GET['error'] == "invalidmailuid") {
                            echo '<p class="signuperror"> FILL VALID MAIL AND USERNAME!</p>';
                        }
                        if ($_GET['error'] == "invalidmail") {
                            echo '<p class="signuperror"> FILL VALID MAIL!</p>';
                        }
                        if ($_GET['error'] == "invaliduid") {
                            echo '<p class="signuperror"> FILL VALID USERNAME!</p>';
                        }
                        if ($_GET['error'] == "passwordcheck") {
                            echo '<p class="signuperror"> PASSWORDS NOT EQUAL!</p>';
                        }
                        if ($_GET['error'] == "sqlerror") {
                            echo '<p class="signuperror"> ERROR 500</p>';
                        }
                    } elseif (isset($_GET['signup']) && $_GET['signup'] == "success") {
                        echo '<p class="signupok"> SUCCESSFUL SINGUP</p>';
                    } 
                 ?>
                <form class="signup-form" action="includes/signup.inc.php" method="post">
                    <div class="row">
                        <div class="col-25">
                          <label for="uid">Username</label>
                        </div>
                        <div class="col-75">
                          <input type="text" name="uid" id="uid" placeholder="Username">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-25">
                            <label for="mail">E-mail</label>
                        </div>
                        <div class="col-75">
                            <input type="text" name="mail" placeholder="E-mail">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-25">
                            <label for="pwd">Password</label>
                        </div>
                        <div class="col-75">
                            <input type="password" name="pwd" placeholder="Password">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-25">
                            <label for="pwd-repeat">Reapet password</label>
                        </div>
                        <div class="col-75">
                            <input type="password" name="pwd-repeat" placeholder="Reapet password">
                        </div>
                    </div>
                    <div class="row">
                        <button type="submit" name="signup-submit">Signup</button>
                    </div>
                </form>
        </div>
    </main>
<?php 
    require "footer.php";
?>