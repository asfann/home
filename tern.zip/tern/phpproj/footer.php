<footer> 
    <div class="footerContent">
        <p>made by <a href="https://www.instagram.com/yiesuas/">me</a></p>
        <p><font color="#ef2e6c">this website is created only for final project</font></p>
        <p>all rights goes to <a href="https://twitter.com/88rising">     
        </a></p>
    </div>
</footer>
</body>
</html>